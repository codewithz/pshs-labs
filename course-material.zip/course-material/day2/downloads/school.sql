-- School report card database for the Day 2 SQL exercises.
-- Works on MariaDB 10.5+ and MySQL 8.
-- Run:  sudo mariadb < school.sql
-- WARNING: this deletes any existing database called school.

DROP DATABASE IF EXISTS school;
CREATE DATABASE school;
USE school;

CREATE TABLE teachers (
  teacher_id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  last_name  VARCHAR(50) NOT NULL,
  email      VARCHAR(100) UNIQUE
);

CREATE TABLE sections (
  section_id  INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(50) NOT NULL,
  grade_level INT NOT NULL,
  adviser_id  INT,
  FOREIGN KEY (adviser_id) REFERENCES teachers(teacher_id)
);

CREATE TABLE students (
  student_id INT AUTO_INCREMENT PRIMARY KEY,
  lrn        CHAR(12) NOT NULL UNIQUE,
  first_name VARCHAR(50) NOT NULL,
  last_name  VARCHAR(50) NOT NULL,
  section_id INT NOT NULL,
  FOREIGN KEY (section_id) REFERENCES sections(section_id)
);

CREATE TABLE subjects (
  subject_id INT AUTO_INCREMENT PRIMARY KEY,
  code       VARCHAR(10) NOT NULL UNIQUE,
  name       VARCHAR(100) NOT NULL,
  units      DECIMAL(3,1) NOT NULL
);

CREATE TABLE grades (
  grade_id    INT AUTO_INCREMENT PRIMARY KEY,
  student_id  INT NOT NULL,
  subject_id  INT NOT NULL,
  teacher_id  INT NOT NULL,
  school_year CHAR(9) NOT NULL,
  semester    TINYINT NOT NULL CHECK (semester IN (1, 2)),
  grade       DECIMAL(5,2),
  UNIQUE (student_id, subject_id, school_year, semester),
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
  FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id)
);

INSERT INTO teachers (first_name, last_name, email) VALUES
  ('Liza', 'Fernandez', 'lfernandez@school.edu.ph'),
  ('Ramon', 'Torres', 'rtorres@school.edu.ph'),
  ('Grace', 'Lim', 'glim@school.edu.ph'),
  ('Dennis', 'Cruz', 'dcruz@school.edu.ph'),
  ('Joy', 'Pascual', 'jpascual@school.edu.ph'),
  ('Allan', 'Domingo', 'adomingo@school.edu.ph'),
  ('Rhea', 'Ocampo', 'rocampo@school.edu.ph'),
  ('Mark', 'Villareal', 'mvillareal@school.edu.ph');

INSERT INTO sections (name, grade_level, adviser_id) VALUES
  ('Sampaguita', 10, 1),
  ('Narra', 10, 2);

INSERT INTO students (lrn, first_name, last_name, section_id) VALUES
  ('136512250001', 'Juan', 'Dela Cruz', 1),
  ('136512250002', 'Maria', 'Santos', 1),
  ('136512250003', 'Jose', 'Reyes', 1),
  ('136512250004', 'Andrea', 'Bautista', 1),
  ('136512250005', 'Miguel', 'Garcia', 1),
  ('136512250006', 'Sofia', 'Mendoza', 2),
  ('136512250007', 'Paolo', 'Villanueva', 2),
  ('136512250008', 'Bea', 'Aquino', 2),
  ('136512250009', 'Carlo', 'Ramos', 2),
  ('136512250010', 'Kristine', 'Navarro', 2),
  ('136512250011', 'Rafael', 'Castillo', 1);

INSERT INTO subjects (code, name, units) VALUES
  ('MATH10', 'Mathematics 10', 1.5),
  ('SCI10', 'Science 10', 1.5),
  ('ENG10', 'English 10', 1.0),
  ('FIL10', 'Filipino 10', 1.0),
  ('AP10', 'Araling Panlipunan 10', 1.0),
  ('CS10', 'Computer Science 10', 1.0);

INSERT INTO grades (student_id, subject_id, teacher_id, school_year, semester, grade) VALUES
  (1, 1, 1, '2025-2026', 1, 88.25),
  (1, 1, 1, '2025-2026', 2, 95.75),
  (1, 2, 2, '2025-2026', 1, 89.00),
  (1, 2, 2, '2025-2026', 2, 95.50),
  (1, 3, 3, '2025-2026', 1, 95.75),
  (1, 3, 3, '2025-2026', 2, 94.75),
  (1, 4, 4, '2025-2026', 1, 94.25),
  (1, 4, 4, '2025-2026', 2, 88.00),
  (1, 5, 5, '2025-2026', 1, 88.50),
  (1, 5, 5, '2025-2026', 2, 94.75),
  (1, 6, 6, '2025-2026', 1, 90.50),
  (1, 6, 6, '2025-2026', 2, 93.00),
  (2, 1, 1, '2025-2026', 1, 89.75),
  (2, 1, 1, '2025-2026', 2, 92.75),
  (2, 2, 2, '2025-2026', 1, 89.00),
  (2, 2, 2, '2025-2026', 2, 92.25),
  (2, 3, 3, '2025-2026', 1, 91.25),
  (2, 3, 3, '2025-2026', 2, 88.00),
  (2, 4, 4, '2025-2026', 1, 89.25),
  (2, 4, 4, '2025-2026', 2, 90.00),
  (2, 5, 5, '2025-2026', 1, 92.50),
  (2, 5, 5, '2025-2026', 2, 85.50),
  (2, 6, 6, '2025-2026', 1, 91.50),
  (2, 6, 6, '2025-2026', 2, 92.25),
  (3, 1, 1, '2025-2026', 1, 82.50),
  (3, 1, 1, '2025-2026', 2, 83.50),
  (3, 2, 2, '2025-2026', 1, 76.50),
  (3, 2, 2, '2025-2026', 2, 78.75),
  (3, 3, 3, '2025-2026', 1, 85.00),
  (3, 3, 3, '2025-2026', 2, 77.75),
  (3, 4, 4, '2025-2026', 1, 82.50),
  (3, 4, 4, '2025-2026', 2, 74.00),
  (3, 5, 5, '2025-2026', 1, 77.75),
  (3, 5, 5, '2025-2026', 2, 83.75),
  (3, 6, 6, '2025-2026', 1, 84.25),
  (3, 6, 6, '2025-2026', 2, 82.75),
  (4, 1, 1, '2025-2026', 1, 85.50),
  (4, 1, 1, '2025-2026', 2, 89.75),
  (4, 2, 2, '2025-2026', 1, 87.50),
  (4, 2, 2, '2025-2026', 2, NULL),
  (4, 3, 3, '2025-2026', 1, 81.00),
  (4, 3, 3, '2025-2026', 2, 88.75),
  (4, 4, 4, '2025-2026', 1, 88.25),
  (4, 4, 4, '2025-2026', 2, 84.25),
  (4, 5, 5, '2025-2026', 1, 88.50),
  (4, 5, 5, '2025-2026', 2, 88.75),
  (4, 6, 6, '2025-2026', 1, 89.75),
  (4, 6, 6, '2025-2026', 2, 81.75),
  (5, 1, 1, '2025-2026', 1, 84.50),
  (5, 1, 1, '2025-2026', 2, 80.50),
  (5, 2, 2, '2025-2026', 1, 87.25),
  (5, 2, 2, '2025-2026', 2, 82.00),
  (5, 3, 3, '2025-2026', 1, 87.00),
  (5, 3, 3, '2025-2026', 2, 84.00),
  (5, 4, 4, '2025-2026', 1, 84.00),
  (5, 4, 4, '2025-2026', 2, 85.25),
  (5, 5, 5, '2025-2026', 1, 79.00),
  (5, 5, 5, '2025-2026', 2, 86.50),
  (5, 6, 6, '2025-2026', 1, 80.50),
  (5, 6, 6, '2025-2026', 2, 82.25),
  (6, 1, 1, '2025-2026', 1, 91.75),
  (6, 1, 1, '2025-2026', 2, 95.75),
  (6, 2, 7, '2025-2026', 1, 96.25),
  (6, 2, 7, '2025-2026', 2, 96.75),
  (6, 3, 3, '2025-2026', 1, 98.75),
  (6, 3, 3, '2025-2026', 2, 93.50),
  (6, 4, 4, '2025-2026', 1, 98.50),
  (6, 4, 4, '2025-2026', 2, 99.00),
  (6, 5, 5, '2025-2026', 1, 97.75),
  (6, 5, 5, '2025-2026', 2, 93.75),
  (6, 6, 6, '2025-2026', 1, 95.50),
  (6, 6, 6, '2025-2026', 2, 97.75),
  (7, 1, 1, '2025-2026', 1, 86.75),
  (7, 1, 1, '2025-2026', 2, 84.00),
  (7, 2, 7, '2025-2026', 1, 79.50),
  (7, 2, 7, '2025-2026', 2, 79.00),
  (7, 3, 3, '2025-2026', 1, 75.00),
  (7, 3, 3, '2025-2026', 2, 78.00),
  (7, 4, 4, '2025-2026', 1, 85.25),
  (7, 4, 4, '2025-2026', 2, 82.50),
  (7, 5, 5, '2025-2026', 1, 79.50),
  (7, 5, 5, '2025-2026', 2, 85.50),
  (7, 6, 6, '2025-2026', 1, 80.25),
  (7, 6, 6, '2025-2026', 2, 86.25),
  (8, 1, 1, '2025-2026', 1, 90.50),
  (8, 1, 1, '2025-2026', 2, 88.75),
  (8, 2, 7, '2025-2026', 1, 86.50),
  (8, 2, 7, '2025-2026', 2, 85.25),
  (8, 3, 3, '2025-2026', 1, 87.00),
  (8, 3, 3, '2025-2026', 2, 94.00),
  (8, 4, 4, '2025-2026', 1, 85.50),
  (8, 4, 4, '2025-2026', 2, 88.50),
  (8, 5, 5, '2025-2026', 1, 85.25),
  (8, 5, 5, '2025-2026', 2, 93.25),
  (8, 6, 6, '2025-2026', 1, 94.00),
  (8, 6, 6, '2025-2026', 2, 87.25),
  (9, 1, 1, '2025-2026', 1, 72.00),
  (9, 1, 1, '2025-2026', 2, 80.50),
  (9, 2, 7, '2025-2026', 1, 75.50),
  (9, 2, 7, '2025-2026', 2, 76.25),
  (9, 3, 3, '2025-2026', 1, 78.50),
  (9, 3, 3, '2025-2026', 2, 80.25),
  (9, 4, 4, '2025-2026', 1, 76.25),
  (9, 4, 4, '2025-2026', 2, 81.50),
  (9, 5, 5, '2025-2026', 1, 82.75),
  (9, 5, 5, '2025-2026', 2, 78.75),
  (9, 6, 6, '2025-2026', 1, 77.25),
  (9, 6, 6, '2025-2026', 2, 76.00),
  (10, 1, 1, '2025-2026', 1, 87.50),
  (10, 1, 1, '2025-2026', 2, 85.00),
  (10, 2, 7, '2025-2026', 1, 87.75),
  (10, 2, 7, '2025-2026', 2, 87.50),
  (10, 3, 3, '2025-2026', 1, 90.25),
  (10, 3, 3, '2025-2026', 2, 86.50),
  (10, 4, 4, '2025-2026', 1, 85.50),
  (10, 4, 4, '2025-2026', 2, 86.75),
  (10, 5, 5, '2025-2026', 1, 84.00),
  (10, 5, 5, '2025-2026', 2, 86.00),
  (10, 6, 6, '2025-2026', 1, 88.25),
  (10, 6, 6, '2025-2026', 2, 82.75);
