/* Day 2 SQL exercises. Blanks are [[answer|other accepted spelling]].
   setup: which tables exist before the student's SQL runs ("full" = all tables + the school data).
   check: "schema" compares table structure; verify: a query run after the student's SQL;
   otherwise the student's last SELECT is compared with the model answer's. */
window.SQLX_EX = {

/* ---------- Part 1: CREATE TABLE ---------- */
c1: { setup:'none', check:'schema', tables:['teachers'],
  code:
`CREATE [[TABLE]] teachers (
  teacher_id INT [[AUTO_INCREMENT]] PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  last_name  VARCHAR(50) [[NOT]] NULL,
  email      VARCHAR(100) [[UNIQUE]]
);`,
  hints:['The statement that makes a new table is <code>CREATE TABLE</code>.',
         'MariaDB numbers new rows for you with <code>AUTO_INCREMENT</code>. Mind the underscore.',
         'Refuse empty values with <code>NOT NULL</code>. Refuse duplicates with <code>UNIQUE</code>.'],
  success:'Your table is ready. The DESCRIBE output below is what you will see in MariaDB too.' },

c2: { setup:'teachers', check:'schema', tables:['sections'],
  code:
`CREATE TABLE sections (
  section_id  INT AUTO_INCREMENT [[PRIMARY KEY]],
  name        VARCHAR(50) NOT NULL,
  grade_level [[INT]] NOT NULL,
  adviser_id  INT,
  [[FOREIGN KEY]] (adviser_id) [[REFERENCES]] teachers([[teacher_id]])
);`,
  hints:['Every table needs one column that identifies each row: the <code>PRIMARY KEY</code>.',
         'Grade level is a whole number like 10, so its type is <code>INT</code>.',
         'A link to another table is written <code>FOREIGN KEY (my_column) REFERENCES other_table(its_column)</code>.',
         'The adviser is a teacher, so the column it points to is the primary key of <code>teachers</code>.'],
  success:'MariaDB will now refuse a section whose adviser_id is not a real teacher.' },

c3: { setup:'teachers,sections', check:'schema', tables:['students'],
  code:
`CREATE TABLE students (
  student_id INT AUTO_INCREMENT PRIMARY KEY,
  lrn        [[CHAR]](12) NOT NULL [[UNIQUE]],
  first_name VARCHAR(50) NOT NULL,
  last_name  VARCHAR(50) NOT NULL,
  section_id INT NOT NULL,
  FOREIGN KEY ([[section_id]]) REFERENCES [[sections]](section_id)
);`,
  hints:['An LRN is always exactly 12 characters. Fixed-length text is <code>CHAR(n)</code>; <code>VARCHAR(n)</code> is for text that varies in length.',
         'Two learners can never share an LRN. Which keyword stops duplicates?',
         'The column in <i>this</i> table that holds the link is <code>section_id</code>, and it points to the <code>sections</code> table.'],
  success:'Every student must now belong to a real section.' },

c4: { setup:'teachers,sections,students,subjects', check:'schema', tables:['grades'],
  code:
`CREATE TABLE grades (
  grade_id    INT AUTO_INCREMENT PRIMARY KEY,
  student_id  INT NOT NULL,
  subject_id  INT NOT NULL,
  teacher_id  INT NOT NULL,
  school_year CHAR(9) NOT NULL,
  semester    TINYINT NOT NULL CHECK (semester IN (1, 2)),
  grade       [[DECIMAL]](5,2),
  [[UNIQUE]] (student_id, subject_id, school_year, semester),
  FOREIGN KEY (student_id) REFERENCES [[students]](student_id),
  FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
  FOREIGN KEY ([[teacher_id]]) REFERENCES teachers(teacher_id)
);`,
  hints:['Grades like 89.25 need an exact type with decimals. <code>DECIMAL(5,2)</code> means 5 digits in total, 2 of them after the point.',
         'One student cannot have two Math grades for the same semester of the same school year. A <code>UNIQUE</code> rule on several columns together says exactly that.',
         'Each grade row links to three other tables: students, subjects and teachers.'],
  success:'That is the whole schema: five tables, linked by four kinds of foreign key.' },

/* ---------- Part 2: INSERT ---------- */
i1: { verify:'SELECT teacher_id, first_name, last_name, email FROM teachers ORDER BY teacher_id', showRows:12, changes:1,
  code:
`INSERT [[INTO]] teachers (first_name, last_name, email)
[[VALUES]] ('Carmela', 'Santiago', 'csantiago@school.edu.ph');`,
  hints:['The pattern is <code>INSERT INTO table (columns) VALUES (values);</code>',
         'You do not give a teacher_id. AUTO_INCREMENT picks the next number.'],
  demos:[{ label:'Insert her twice', sql:"INSERT INTO teachers (first_name, last_name, email) VALUES ('Carmela', 'Santiago', 'csantiago@school.edu.ph'); INSERT INTO teachers (first_name, last_name, email) VALUES ('Carmela', 'Santiago', 'csantiago@school.edu.ph');" }],
  success:'Ms. Santiago got teacher_id 9 because teachers 1 to 8 already exist.' },

i2: { verify:'SELECT * FROM subjects ORDER BY subject_id', changes:2,
  code:
`INSERT INTO subjects (code, name, units) VALUES
  ('RES10', 'Research 10', 1.0)[[,]]
  ('MAPEH10', 'MAPEH 10', [[1.0|1|1.00]]);`,
  hints:['Several rows in one INSERT are separated by a comma: <code>(…), (…), (…);</code>',
         'Units are a number. Numbers have no quotes. Both new subjects carry 1.0 unit.'],
  success:'One INSERT, two rows. This is how the school data file loads all 120 grades at once.' },

i3: { verify:"SELECT lrn, first_name, last_name, section_id FROM students WHERE lrn = '136512250012'", changes:1,
  code:
`INSERT INTO students (lrn, first_name, last_name, section_id)
VALUES ('136512250012', 'Liza Mae', 'Torralba', [[2]]);`,
  hints:['Look at the sections table in the schema: Sampaguita is 1, Narra is 2.'],
  demos:[{ label:'Try section 99', sql:"INSERT INTO students (lrn, first_name, last_name, section_id) VALUES ('136512250012', 'Liza Mae', 'Torralba', 99);" }],
  success:'The foreign key checked that section 2 exists before it let the row in.' },

/* ---------- Part 3: SELECT ---------- */
s1: { code:`SELECT [[first_name]], [[last_name]] [[FROM]] students;`,
  hints:['Column names are in the schema card for <code>students</code>. First name first.', 'After the columns comes <code>FROM</code> and the table name.'] },

s2: { code:`SELECT first_name, last_name FROM students [[WHERE]] section_id [[=]] 1;`,
  hints:['Filtering rows is the job of <code>WHERE</code>.', 'SQL compares with a single <code>=</code>, not <code>==</code>.'] },

s3: { code:
`SELECT student_id, subject_id, semester, grade
FROM grades
WHERE grade [[<]] [[75]];`,
  hints:['The passing grade is 75. A failing grade is anything below it.', 'Below is <code>&lt;</code>. A grade of exactly 75 passes, so do not use <code>&lt;=</code>.'],
  success:'Two failing grades: student 9 in Math (semester 1) and student 3 in Filipino (semester 2).' },

s4: { code:
`SELECT student_id, subject_id, semester
FROM grades
WHERE grade [[IS]] [[NULL]];`,
  hints:['A missing grade (INC) is stored as NULL, which means "no value".', 'NULL is never equal to anything, not even to NULL. You must write <code>IS NULL</code>.'],
  demos:[{ label:'Try = NULL', sql:'SELECT student_id, subject_id, semester FROM grades WHERE grade = NULL;', note:'Zero rows, and no error message. That silence is what makes this bug hard to spot.' }],
  success:'Andrea (student 4) has no Science grade for semester 2 yet.' },

s5: { code:
`SELECT student_id, subject_id, grade
FROM grades
WHERE semester = 2 [[AND]] grade [[BETWEEN]] 75 AND 79.99;`,
  hints:['Both conditions must be true, so join them with <code>AND</code>.', '<code>BETWEEN low AND high</code> includes both ends.'] },

s6: { code:
`SELECT student_id, grade
FROM grades
WHERE subject_id = 6 AND semester = 1
[[ORDER BY]] grade [[DESC]], student_id
[[LIMIT]] 3;`,
  hints:['Sorting is <code>ORDER BY</code>. Highest first is <code>DESC</code> (descending).', 'Keep only the first rows with <code>LIMIT n</code>. It always goes last.'],
  success:'The <code>, student_id</code> after DESC breaks ties, so two students with the same grade always come out in the same order.' },

s7: { code:
`SELECT first_name, last_name
FROM students
WHERE last_name [[LIKE]] 'R[[%]]';`,
  hints:['Pattern matching uses <code>LIKE</code>.', 'In a LIKE pattern, <code>%</code> means "any characters, any number of them".'] },

/* ---------- Part 4: UPDATE and DELETE ---------- */
u1: { verify:'SELECT grade_id, student_id, subject_id, semester, grade FROM grades WHERE student_id = 4 ORDER BY grade_id', changes:1, showRows:12,
  code:
`UPDATE grades
SET grade = [[84|84.00]]
[[WHERE]] student_id = 4 AND subject_id = [[2]] AND semester = 2;`,
  hints:['The new grade is 84.', 'Without <code>WHERE</code> you change every row. You saw that above.', 'Science is subject_id 2 in the subjects table.'],
  demos:[{ label:'Forget the WHERE', sql:'UPDATE grades SET grade = 84;', after:'SELECT student_id, subject_id, semester, grade FROM grades LIMIT 8', note:'Every student now has 84 in every subject.' }],
  success:'1 row affected. Always read that number. If it says 120, you have a problem.' },

u2: { verify:'SELECT student_id, first_name, last_name FROM students ORDER BY student_id', changes:1,
  code:`UPDATE students SET [[first_name]] = 'Beatriz' WHERE [[student_id]] = 8;`,
  hints:['You are changing the first name column.', 'Find the row by its primary key. That is the safest WHERE there is.'] },

u3: { verify:'SELECT student_id, first_name, last_name FROM students ORDER BY student_id', changes:1,
  code:`[[DELETE]] FROM students [[WHERE]] student_id = 11;`,
  hints:['Removing rows is <code>DELETE FROM table WHERE …</code>.'],
  demos:[{ label:'Delete Juan (id 1) instead', sql:'DELETE FROM students WHERE student_id = 1;' }],
  success:'Rafael had no grades, so nothing pointed to him and the delete was allowed.' },

/* ---------- Part 5: aggregates ---------- */
a1: { code:`SELECT [[COUNT]](*) FROM students;`,
  hints:['The function that counts rows is <code>COUNT</code>.'] },

a2: { code:
`SELECT subject_id, [[ROUND]]([[AVG]](grade), 2) AS average
FROM grades
[[GROUP BY]] subject_id;`,
  hints:['Average is <code>AVG</code>. Rounding to 2 decimals is <code>ROUND(value, 2)</code>.', 'One result row per subject: <code>GROUP BY subject_id</code>.'] },

a3: { code:
`SELECT subject_id, [[MIN]](grade) AS lowest, [[MAX]](grade) AS highest
FROM grades
GROUP BY [[subject_id]];`,
  hints:['Smallest is <code>MIN</code>, largest is <code>MAX</code>.', 'You want one row per subject, so group by the subject column.'] },

a4: { code:
`SELECT student_id, ROUND(AVG(grade), 2) AS average
FROM grades
GROUP BY student_id
[[HAVING]] AVG(grade) [[>=]] 90
ORDER BY average DESC;`,
  hints:['WHERE filters rows before grouping. A filter on an average happens after grouping, so it needs <code>HAVING</code>.', 'With Honors starts at 90, and 90 itself counts.'],
  success:'Sofia, Juan and Maria. Sofia is above 95 (With High Honors).' },

/* ---------- Part 6: JOIN ---------- */
j1: { code:
`SELECT students.first_name, students.last_name, sections.name
FROM students
[[JOIN]] sections [[ON]] students.section_id = sections.[[section_id]];`,
  hints:['Combining tables is <code>JOIN other_table ON how_they_match</code>.', 'Match the foreign key in students to the primary key in sections.'] },

j2: { code:
`SELECT sec.name, t.first_name, t.last_name
FROM sections [[sec]]
JOIN teachers t ON sec.adviser_id = t.[[teacher_id]];`,
  hints:['The SELECT line already uses the short name <code>sec</code> for sections. Give the table that alias.', 'adviser_id points to the primary key of teachers.'] },

j3: { code:
`SELECT sub.name, g.grade
FROM grades g
JOIN subjects sub ON g.[[subject_id]] = sub.subject_id
WHERE g.student_id = 1 AND g.semester = [[1]]
ORDER BY sub.[[name]];`,
  hints:['grades and subjects share the column <code>subject_id</code>.', 'First semester is 1. Sort alphabetically by the subject name.'] },

j4: { names:true, showRows:12, code:
`SELECT st.lrn, st.first_name, st.last_name, sec.name AS section,
       sub.name AS subject,
       CONCAT(t.first_name, ' ', t.last_name) AS teacher,
       g.semester, g.grade
FROM grades g
JOIN students st  ON g.student_id = st.[[student_id]]
JOIN sections sec ON st.[[section_id]] = sec.section_id
JOIN subjects sub ON g.subject_id = sub.subject_id
[[JOIN]] teachers t ON g.[[teacher_id]] = t.teacher_id
WHERE st.lrn = '136512250001'
ORDER BY g.semester, sub.name;`,
  hints:['Each JOIN matches a foreign key to the primary key with the same name.', 'The section link lives in the students table (<code>st</code>), not in grades.', 'The teacher who gave the grade is stored in grades as <code>teacher_id</code>.'],
  success:'That is Juan Dela Cruz\'s report card, rebuilt from four tables. Hold it next to the paper version.' },

/* ---------- Stretch track ---------- */
x1: { track:'stretch', free:true,
  starter:'-- Students who have no grades at all\n',
  solution:
`SELECT st.first_name, st.last_name
FROM students st
LEFT JOIN grades g ON g.student_id = st.student_id
WHERE g.grade_id IS NULL;`,
  hints:['A plain JOIN drops students with no matching grade. A <code>LEFT JOIN</code> keeps them and fills the grade columns with NULL.', 'Keep only the rows where the grade side is NULL.'],
  success:'Rafael. A plain JOIN would have hidden him completely.' },

x2: { track:'stretch', free:true,
  starter:'-- Teachers who advise no section AND gave no grade\n',
  solution:
`SELECT t.first_name, t.last_name
FROM teachers t
WHERE NOT EXISTS (SELECT 1 FROM grades g WHERE g.teacher_id = t.teacher_id)
  AND NOT EXISTS (SELECT 1 FROM sections s WHERE s.adviser_id = t.teacher_id);`,
  hints:['Two LEFT JOINs work, but you may get duplicate rows. <code>NOT EXISTS (subquery)</code> is cleaner.', 'Check both tables that point at teachers: grades.teacher_id and sections.adviser_id.'] },

x3: { track:'stretch', free:true, names:true,
  starter:'-- Juan\'s report card, one row per subject:\n-- subject | sem1 | sem2 | final | remarks\n-- final = average of the two semesters, rounded to 2 decimals\n-- remarks = \'Passed\' if final >= 75, otherwise \'Failed\'\n',
  solution:
`SELECT sub.name AS subject,
       MAX(CASE WHEN g.semester = 1 THEN g.grade END) AS sem1,
       MAX(CASE WHEN g.semester = 2 THEN g.grade END) AS sem2,
       ROUND(AVG(g.grade), 2) AS final,
       CASE WHEN AVG(g.grade) >= 75 THEN 'Passed' ELSE 'Failed' END AS remarks
FROM grades g
JOIN subjects sub ON sub.subject_id = g.subject_id
WHERE g.student_id = 1
GROUP BY sub.subject_id, sub.name
ORDER BY sub.name;`,
  hints:['Group by subject. Inside each group, <code>CASE WHEN g.semester = 1 THEN g.grade END</code> keeps only the semester 1 value.', 'Wrap that CASE in MAX() so each group collapses to one value. This trick is called a pivot.', 'Name the columns exactly: subject, sem1, sem2, final, remarks.'] },

x4: { track:'stretch', free:true, names:true,
  starter:'-- General weighted average (GWA) for every student who has grades.\n-- GWA = SUM(grade × units) / SUM(units)\n-- Columns: student_id, gwa (2 decimals). Highest GWA first.\n',
  solution:
`SELECT g.student_id,
       ROUND(SUM(g.grade * sub.units) / SUM(sub.units), 2) AS gwa
FROM grades g
JOIN subjects sub ON sub.subject_id = g.subject_id
WHERE g.grade IS NOT NULL
GROUP BY g.student_id
ORDER BY gwa DESC;`,
  hints:['JOIN subjects to get each grade\'s units.', 'Check student 4. Her missing Science grade adds nothing to SUM(grade × units), but its units still count in SUM(units). Leave NULL grades out.'],
  success:'Did you catch Andrea\'s missing grade? Without <code>WHERE g.grade IS NOT NULL</code> her GWA comes out about 13 points too low.' },

x5: { track:'stretch', free:true, names:true,
  starter:'-- Class ranking inside each section by general average.\n-- Columns: section, student_id, average (2 decimals), rnk\n-- Order by section name, then rank.\n',
  solution:
`SELECT sec.name AS section, st.student_id,
       ROUND(AVG(g.grade), 2) AS average,
       RANK() OVER (PARTITION BY sec.section_id ORDER BY AVG(g.grade) DESC) AS rnk
FROM grades g
JOIN students st  ON st.student_id = g.student_id
JOIN sections sec ON sec.section_id = st.section_id
GROUP BY sec.section_id, sec.name, st.student_id
ORDER BY sec.name, rnk;`,
  hints:['Window functions run after GROUP BY. <code>RANK() OVER (PARTITION BY … ORDER BY …)</code> restarts the count for each section.', 'Avoid naming the column <code>rank</code>. MySQL 8 treats it as a reserved word, so your query would break there.'] },

x6: { track:'stretch', free:true, names:true,
  starter:'-- Students whose own average is above the average of ALL grades in the school.\n-- Columns: student_id, average (2 decimals). Order by student_id.\n',
  solution:
`SELECT student_id, ROUND(AVG(grade), 2) AS average
FROM grades
GROUP BY student_id
HAVING AVG(grade) > (SELECT AVG(grade) FROM grades)
ORDER BY student_id;`,
  hints:['A subquery in brackets can produce one number: <code>(SELECT AVG(grade) FROM grades)</code>.', 'Compare each student\'s average to it in HAVING.'] },

x7: { track:'stretch', free:true,
  verify:'SELECT grade_id, grade FROM grades ORDER BY grade_id', showRows:6,
  mustContain:[['START\\s+TRANSACTION|BEGIN','Open a transaction first with START TRANSACTION.'],['UPDATE\\s+grades','Run the dangerous UPDATE (no WHERE) inside the transaction.'],['ROLLBACK','End with ROLLBACK so the damage is undone.']],
  starter:'-- 1. Start a transaction\n-- 2. UPDATE grades SET grade = 50;   (no WHERE, on purpose)\n-- 3. SELECT a few grades to see the damage\n-- 4. Undo everything\n',
  solution:
`START TRANSACTION;
UPDATE grades SET grade = 50;
SELECT * FROM grades LIMIT 5;
ROLLBACK;`,
  hints:['<code>START TRANSACTION;</code> … <code>ROLLBACK;</code> undoes every change in between. <code>COMMIT;</code> would keep them.'],
  success:'The check query shows the original grades: the rollback worked.' }
};
