/* Day 1 course pages: shared framework: theme, projector controls, TOC, copy buttons,
   simulated terminal (Term), animated step player (Scene) and flow diagrams (Flow). Offline, no deps. */
(function(){
'use strict';
const store = {
  get(k,d){ try{ const v = localStorage.getItem(k); return v===null? d : JSON.parse(v); }catch(e){ return d; } },
  set(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
};
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
window.C = { store, esc, sleep };

/* ---------------- theme + font ---------------- */
const root = document.documentElement;
function setTheme(t){ root.dataset.theme = t; store.set('theme', t); const b=document.getElementById('themeBtn'); if(b) b.innerHTML = t==='dark' ? '☀️ Light' : '🌙 Dark'; }
let theme = store.get('theme', null);
if(!theme){ theme = (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light'; }
root.dataset.theme = theme;
let fs = store.get('fs', 20);
root.style.setProperty('--fs', fs+'px');
function setExplain(on){ store.set('explain', on); document.querySelectorAll('details.explain').forEach(d => d.open = on); const b=document.getElementById('explainBtn'); if(b){ b.classList.toggle('on', on); b.innerHTML = on ? '💡 Explain: on' : '💡 Explain: off'; } }
function bumpFont(d){ fs = Math.max(14, Math.min(34, fs+d)); root.style.setProperty('--fs', fs+'px'); store.set('fs', fs); }

/* ---------------- shell code blocks ---------------- */
function decorateShell(){
  document.querySelectorAll('pre.sh').forEach(pre => {
    if(pre.dataset.done) return; pre.dataset.done = 1;
    const raw = pre.textContent.replace(/^\n+|\s+$/g,'');
    const lines = raw.split('\n');
    if(pre.classList.contains('code')){ /* source code: no prompt, # is not a comment, copy as is */
      pre.innerHTML = (pre.dataset.file ? '<span class="fname">'+esc(pre.dataset.file)+'</span>' : '') + esc(raw);
      const cb = document.createElement('button'); cb.className='copy'; cb.textContent='Copy'; cb.title='Copy code';
      cb.addEventListener('click', () => copy(raw, cb)); pre.appendChild(cb); return;
    }
    const noPrompt = pre.classList.contains('np');
    pre.innerHTML = lines.map(l => {
      if(/^\s*#/.test(l)) return '<span class="c">'+esc(l)+'</span>';
      if(noPrompt || l.trim()==='' || /^\s/.test(l)) return esc(l);
      return '<span class="p">$ </span>'+esc(l);
    }).join('\n');
    const copyText = lines.filter(l => !/^\s*#/.test(l)).join('\n').trim();
    const b = document.createElement('button'); b.className='copy'; b.textContent='Copy'; b.title='Copy command';
    b.addEventListener('click', () => copy(copyText, b));
    pre.appendChild(b);
  });
}
function copy(text, btn){
  const done = () => { btn.textContent='Copied ✓'; btn.classList.add('done'); setTimeout(()=>{btn.textContent='Copy'; btn.classList.remove('done');},1400); };
  if(navigator.clipboard && window.isSecureContext){ navigator.clipboard.writeText(text).then(done, () => fallback()); }
  else fallback();
  function fallback(){ const ta=document.createElement('textarea'); ta.value=text; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.select(); try{document.execCommand('copy'); done();}catch(e){} ta.remove(); }
}

/* ---------------- practice steps (tick off) ---------------- */
function decorateSteps(){
  const page = location.pathname.split('/').pop() || 'index';
  document.querySelectorAll('ol.steps').forEach((ol, oi) => {
    ol.querySelectorAll(':scope > li').forEach((li, li_i) => {
      const key = 'step:'+page+':'+oi+':'+li_i;
      if(store.get(key,false)) li.classList.add('done');
      const t = document.createElement('span'); t.className='tick'; t.title='Mark done';
      t.addEventListener('click', () => { li.classList.toggle('done'); store.set(key, li.classList.contains('done')); });
      li.prepend(t);
    });
  });
}

/* ---------------- topbar, TOC, keyboard ---------------- */
function buildChrome(){
  const bar = document.querySelector('.topbar');
  if(bar){
    const tools = document.createElement('div'); tools.style.display='flex'; tools.style.gap='.4rem';
    tools.innerHTML = '<button class="btn ghost" id="tocBtn" title="Toggle contents (T)">☰</button>'+
      '<button class="btn ghost" id="fsDown" title="Smaller text (-)">A−</button>'+
      '<button class="btn ghost" id="fsUp" title="Bigger text (+)">A+</button>'+
      '<button class="btn ghost" id="explainBtn" title="Show / hide all explanations (E)">💡 Explain</button>'+
      '<button class="btn" id="themeBtn" title="Dark / light (D)"></button>'+
      '<button class="btn ghost" id="helpBtn" title="Keyboard shortcuts (?)">⌨︎</button>';
    bar.appendChild(tools);
    const pb = document.createElement('div'); pb.className='progress'; bar.appendChild(pb);
    window.addEventListener('scroll', () => { const h = document.documentElement; pb.style.width = (100*h.scrollTop/Math.max(1,h.scrollHeight-h.clientHeight))+'%'; }, {passive:true});
    document.getElementById('tocBtn').onclick = () => document.body.classList.toggle('toc-hidden');
    document.getElementById('fsDown').onclick = () => bumpFont(-2);
    document.getElementById('fsUp').onclick = () => bumpFont(2);
    const exBtn = document.getElementById('explainBtn');
    if(!document.querySelector('details.explain')) exBtn.style.display='none';
    exBtn.onclick = () => setExplain(!store.get('explain', true));
    setExplain(store.get('explain', true));
    document.getElementById('themeBtn').onclick = () => setTheme(root.dataset.theme==='dark'?'light':'dark');
    document.getElementById('helpBtn').onclick = () => help.classList.toggle('show');
    setTheme(root.dataset.theme);
  }
  const toc = document.querySelector('nav.toc');
  const items = [...document.querySelectorAll('.module, .unit')];
  if(toc){
    items.forEach((el,i) => {
      if(!el.id) el.id = 'u'+i;
      const h = el.querySelector('h1, h2'); if(!h) return;
      const a = document.createElement('a'); a.href = '#'+el.id;
      a.className = el.classList.contains('module') ? 'lvl1' : 'lvl2';
      a.textContent = (el.dataset.toc || h.textContent).trim();
      toc.appendChild(a);
    });
    const links = [...toc.querySelectorAll('a')];
    const io = new IntersectionObserver(es => {
      es.forEach(e => { if(e.isIntersecting){ links.forEach(l => l.classList.toggle('active', l.getAttribute('href')==='#'+e.target.id)); const act = toc.querySelector('a.active'); if(act) act.scrollIntoView({block:'nearest'}); } });
    }, {rootMargin:'-20% 0px -70% 0px'});
    items.forEach(el => io.observe(el));
  }
  const help = document.createElement('div'); help.className='help-overlay';
  help.innerHTML = '<div class="box"><h3 style="margin-top:0">Keyboard shortcuts</h3><table>'+
    '<tr><td><kbd>N</kbd> / <kbd>J</kbd></td><td>Next section</td></tr>'+
    '<tr><td><kbd>P</kbd> / <kbd>K</kbd></td><td>Previous section</td></tr>'+
    '<tr><td><kbd>Space</kbd></td><td>Play / pause the animation in the current section</td></tr>'+
    '<tr><td><kbd>→</kbd></td><td>Next animation step (when not typing)</td></tr>'+
    '<tr><td><kbd>+</kbd> / <kbd>−</kbd></td><td>Bigger / smaller text</td></tr>'+
    '<tr><td><kbd>D</kbd></td><td>Dark / light mode</td></tr>'+
    '<tr><td><kbd>T</kbd></td><td>Hide / show contents</td></tr>'+
    '<tr><td><kbd>E</kbd></td><td>Show / hide all 💡 explanations</td></tr>'+
    '<tr><td><kbd>?</kbd></td><td>This help</td></tr></table><p class="dim">Click anywhere to close.</p></div>';
  help.onclick = () => help.classList.remove('show');
  document.body.appendChild(help);

  function current(){
    const y = 90; let best = items[0];
    for(const el of items){ if(el.getBoundingClientRect().top <= y+5) best = el; }
    return best;
  }
  function go(d){
    const cur = current(); let i = items.indexOf(cur) + d;
    if(d>0 && cur.getBoundingClientRect().top > 100) i = items.indexOf(cur);
    i = Math.max(0, Math.min(items.length-1, i));
    const el = items[i]; el.scrollIntoView({behavior:'smooth', block:'start'});
    document.querySelectorAll('.unit.focus').forEach(u => u.classList.remove('focus'));
    if(el.classList.contains('unit')){ el.classList.add('focus'); setTimeout(()=>el.classList.remove('focus'), 1500); }
  }
  function sceneInView(){
    let best=null, bestD=1e9;
    document.querySelectorAll('.scene').forEach(s => { const r=s.getBoundingClientRect(); if(r.bottom>0 && r.top<innerHeight){ const d=Math.abs(r.top+r.height/2-innerHeight/2); if(d<bestD){bestD=d; best=s;} } });
    return best && best._scene;
  }
  document.addEventListener('keydown', e => {
    const tag = (e.target.tagName||'').toLowerCase();
    if(tag==='input' || tag==='textarea' || e.target.isContentEditable || e.ctrlKey || e.metaKey || e.altKey) return;
    const k = e.key;
    if(k==='n'||k==='j'){ go(1); e.preventDefault(); }
    else if(k==='p'||k==='k'){ go(-1); e.preventDefault(); }
    else if(k==='+'||k==='='){ bumpFont(2); }
    else if(k==='-'||k==='_'){ bumpFont(-2); }
    else if(k==='d'){ setTheme(root.dataset.theme==='dark'?'light':'dark'); }
    else if(k==='e'){ setExplain(!store.get('explain', true)); }
    else if(k==='t'){ document.body.classList.toggle('toc-hidden'); }
    else if(k==='?'){ help.classList.toggle('show'); }
    else if(k===' '){ const s=sceneInView(); if(s){ e.preventDefault(); s.toggle(); } }
    else if(k==='ArrowRight'){ const s=sceneInView(); if(s){ e.preventDefault(); s.pause(); s.next(); } }
  });
}

/* ---------------- simulated terminal ---------------- */
class Term {
  constructor(el, opt={}){
    this.el = el; this.opt = opt; this.hist = []; this.hi = 0;
    el.classList.add('term');
    el.innerHTML = '<div class="bar"><i></i><i></i><i></i><span>'+esc(opt.title||'student@lab01: ~')+'</span></div><div class="screen"></div>';
    this.screen = el.querySelector('.screen');
    if(opt.interactive !== false && opt.exec) this.addInput();
    if(opt.banner) this.print(opt.banner, 'dim');
  }
  promptHTML(){ return this.opt.prompt ? this.opt.prompt() : '<span class="pr">student@lab01:<b>~</b>$</span>'; }
  addInput(){
    const row = document.createElement('div'); row.className='inrow';
    row.innerHTML = '<span class="pp"></span><input spellcheck="false" autocomplete="off" autocapitalize="off" aria-label="Type a command">';
    this.screen.appendChild(row); this.inrow = row; this.input = row.querySelector('input');
    this.refreshPrompt();
    this.input.addEventListener('keydown', e => {
      if(e.key==='Enter'){ const v=this.input.value; this.input.value=''; this.run(v); if(v.trim()) { this.hist.push(v); } this.hi=this.hist.length; }
      else if(e.key==='ArrowUp'){ if(this.hi>0){ this.hi--; this.input.value=this.hist[this.hi]; } e.preventDefault(); }
      else if(e.key==='ArrowDown'){ if(this.hi<this.hist.length){ this.hi++; this.input.value=this.hist[this.hi]||''; } e.preventDefault(); }
      else if(e.key==='Tab'){ e.preventDefault(); if(this.opt.complete){ const v=this.opt.complete(this.input.value); if(v) this.input.value=v; } }
      else if(e.key==='l' && e.ctrlKey){ e.preventDefault(); this.clear(); }
      else if(e.key==='c' && e.ctrlKey){ e.preventDefault(); this.echoPrompt(this.input.value+'^C'); this.input.value=''; }
    });
    this.screen.addEventListener('click', () => { if(!getSelection().toString()) this.input.focus({preventScroll:true}); });
  }
  refreshPrompt(){ if(this.inrow) this.inrow.querySelector('.pp').innerHTML = this.promptHTML(); }
  append(node){ if(this.inrow) this.screen.insertBefore(node, this.inrow); else this.screen.appendChild(node); this.screen.scrollTop = this.screen.scrollHeight; }
  print(text, cls){
    if(text===undefined || text===null) return;
    String(text).split('\n').forEach(t => { const d=document.createElement('div'); d.className='line'+(cls?' '+cls:''); d.textContent=t; this.append(d); });
  }
  printHTML(html){ const d=document.createElement('div'); d.className='line'; d.innerHTML=html; this.append(d); }
  echoPrompt(cmd){ const d=document.createElement('div'); d.className='line'; d.innerHTML=this.promptHTML()+' '+esc(cmd); this.append(d); return d; }
  clear(){ [...this.screen.children].forEach(c => { if(c!==this.inrow) c.remove(); }); }
  output(res){
    if(res===undefined || res===null) return;
    if(typeof res === 'string'){ this.print(res); return; }
    if(Array.isArray(res)){ res.forEach(r => typeof r==='string' ? this.print(r) : (r.html!==undefined ? this.printHTML(r.html) : this.print(r.t, r.c))); return; }
    if(res.clear){ this.clear(); return; }
    if(res.html!==undefined){ this.printHTML(res.html); return; }
    this.print(res.t, res.c);
  }
  run(line){
    const d = this.echoPrompt(line);
    if(!line.trim()){ this.refreshPrompt(); return; }
    let res; try{ res = this.opt.exec(line); }catch(err){ res = {t:String(err.message||err), c:'err'}; }
    this.output(res); this.refreshPrompt();
    return res;
  }
  async type(line, fast, speed=1){
    if(fast){ return this.run(line); }
    const d = document.createElement('div'); d.className='line'; d.innerHTML = this.promptHTML()+' <span class="typed"></span><span class="cursor">&nbsp;</span>';
    this.append(d);
    const t = d.querySelector('.typed');
    for(const ch of line){ t.textContent += ch; await sleep((28+Math.random()*45)/speed); }
    await sleep(260/speed);
    d.remove();
    return this.run(line);
  }
}
window.Term = Term;

/* ---------------- Scene: an animated, step-through "video" ---------------- */
class Scene {
  /* opt: { el, steps:[{cmd, caption, act(ctx), after(res,ctx), wait}], term, reset(), wide } */
  constructor(opt){
    this.o = opt; this.i = 0; this.playing = false; this.busy = false; this.speed = 1; this.gen = 0;
    const el = opt.el; el.classList.add('scene'); el._scene = this;
    const ctr = document.createElement('div'); ctr.className='controls';
    ctr.innerHTML = '<button class="btn primary play">▶ Play</button><button class="btn step">Step ⏭</button><button class="btn ghost restart" title="Start over">↺</button>'+
      '<button class="btn ghost spd" title="Speed">1×</button><div class="caption"></div><div class="dots"></div>';
    el.appendChild(ctr);
    this.cap = ctr.querySelector('.caption'); this.dots = ctr.querySelector('.dots');
    this.playBtn = ctr.querySelector('.play');
    this.playBtn.onclick = () => this.toggle();
    ctr.querySelector('.step').onclick = () => { this.pause(); this.next(); };
    ctr.querySelector('.restart').onclick = () => this.restart();
    const spd = ctr.querySelector('.spd');
    spd.onclick = () => { this.speed = this.speed===1?2:(this.speed===2?0.6:1); spd.textContent = (this.speed===0.6?'0.6':this.speed)+'×'; };
    opt.steps.forEach((s,k) => { const d=document.createElement('i'); d.title = s.caption ? s.caption.replace(/<[^>]+>/g,'') : (s.cmd||''); d.onclick=()=>this.jump(k); this.dots.appendChild(d); });
    this.setCaption(opt.intro || 'Press <b>▶ Play</b> (or <kbd>Space</kbd>) to run the animation, or <b>Step</b> to go one move at a time.');
    this.paint();
    if(opt.reset) opt.reset({fast:true});
  }
  setCaption(h){ this.cap.innerHTML = h; }
  paint(){ [...this.dots.children].forEach((d,k) => { d.className = k < this.i ? 'on' : ''; if(k===this.i-1) d.className='cur'; }); }
  ctx(fast){ return { fast, speed:this.speed, term:this.o.term, scene:this }; }
  async runStep(k, fast){
    const s = this.o.steps[k]; const ctx = this.ctx(fast); this.curStep = s;
    if(s.caption) this.setCaption(s.caption);
    if(s.before) await s.before(ctx);
    let res;
    if(s.cmd !== undefined && this.o.term){
      const t = s.term || this.o.term;
      if(s.prompt) t.opt.prompt = s.prompt;
      res = await t.type(s.cmd, fast, this.speed);
    }
    if(s.act) res = await s.act(ctx);
    if(s.after) await s.after(res, ctx);
  }
  async next(){
    if(this.busy) return;
    if(this.i >= this.o.steps.length){ this.setCaption('✅ End of animation. Press ↺ to replay, or try it yourself in the terminal.'); this.pause(); return; }
    this.busy = true; const g = this.gen;
    try{ await this.runStep(this.i, false); }finally{ if(g===this.gen){ this.i++; this.paint(); } this.busy = false; }
    if(this.i >= this.o.steps.length && this.playing){ this.pause(); this.setCaption((this.o.steps[this.i-1].caption||'') + ' <span class="pill">end</span>'); }
  }
  async loop(){
    while(this.playing && this.i < this.o.steps.length){
      await this.next();
      const s = this.o.steps[this.i-1] || {};
      const w = (s.wait || this.o.wait || 1900) / this.speed;
      const t0 = Date.now(); while(this.playing && Date.now()-t0 < w) await sleep(60);
    }
    this.pause();
  }
  toggle(){ this.playing ? this.pause() : this.play(); }
  play(){ if(this.i >= this.o.steps.length) { this.restart(true); return; } this.playing = true; this.playBtn.textContent='⏸ Pause'; this.loop(); }
  pause(){ this.playing = false; this.playBtn.textContent='▶ Play'; }
  async restart(autoplay){
    this.pause(); this.gen++; while(this.busy) await sleep(50);
    this.i = 0; if(this.o.term) this.o.term.clear(); (this.o.extraTerms||[]).forEach(t=>t.clear());
    if(this.o.reset) await this.o.reset({fast:true});
    this.paint(); this.setCaption(this.o.intro || 'Ready.');
    if(autoplay===true) this.play();
  }
  async jump(k){
    this.pause(); this.gen++; while(this.busy) await sleep(50);
    this.i = 0; if(this.o.term) this.o.term.clear(); (this.o.extraTerms||[]).forEach(t=>t.clear());
    if(this.o.reset) await this.o.reset({fast:true});
    this.busy = true;
    for(let j=0;j<k;j++){ await this.runStep(j, true); }
    this.i = k; this.busy = false; this.paint();
    await this.next();
  }
}
window.Scene = Scene;

/* ---------------- Flow diagram with travelling tokens ---------------- */
class Flow {
  /* nodes: [{id,x,y,icon,title,sub}] (x,y in %), wires: [[a,b],...] */
  constructor(el, nodes, wires=[], height){
    this.el = el; el.classList.add('flow'); if(height) el.style.height = height+'px';
    this.nodes = {};
    const svg = document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('class','wires'); el.appendChild(svg); this.svg = svg;
    nodes.forEach(n => {
      const d = document.createElement('div'); d.className='node'; d.style.left=n.x+'%'; d.style.top=n.y+'%';
      d.innerHTML = (n.icon?'<span class="big">'+n.icon+'</span>':'')+'<b>'+n.title+'</b>'+(n.sub?'<small>'+n.sub+'</small>':'');
      el.appendChild(d); this.nodes[n.id] = {el:d, ...n};
    });
    this.wires = wires;
    this.drawWires(); window.addEventListener('resize', () => this.drawWires());
  }
  pos(id){ const n=this.nodes[id]; return {x:n.x/100*this.el.clientWidth, y:n.y/100*this.el.clientHeight}; }
  drawWires(){
    this.svg.innerHTML = this.wires.map(([a,b]) => { const p=this.pos(a), q=this.pos(b); return '<path d="M'+p.x+' '+p.y+' L'+q.x+' '+q.y+'"/>'; }).join('');
  }
  set(id, cls, html){ const n=this.nodes[id].el; n.classList.remove('lit','good','badn','off'); if(cls) cls.split(' ').forEach(c=>n.classList.add(c)); if(html!==undefined){ n.querySelector('small') ? n.querySelector('small').innerHTML=html : null; } }
  sub(id, html){ const s=this.nodes[id].el.querySelector('small'); if(s) s.innerHTML = html; }
  clear(){ Object.values(this.nodes).forEach(n => n.el.classList.remove('lit','good','badn')); this.el.querySelectorAll('.token').forEach(t=>t.remove()); }
  async send(a, b, label, cls, ctx){
    if(ctx && ctx.fast) return;
    const p=this.pos(a), q=this.pos(b);
    const t=document.createElement('div'); t.className='token'+(cls?' '+cls:''); t.textContent=label; this.el.appendChild(t);
    const dur = 1100/((ctx&&ctx.speed)||1);
    const anim = t.animate([{left:p.x+'px',top:p.y+'px',opacity:0},{opacity:1,offset:.1},{opacity:1,offset:.9},{left:q.x+'px',top:q.y+'px',opacity:0}], {duration:dur, easing:'ease-in-out'});
    await anim.finished.catch(()=>{}); t.remove();
  }
}
window.Flow = Flow;

/* terminal (canned output) on the left + flow diagram on the right, driven by a Scene */
window.makeFlowScene = function(el, o){
  el.innerHTML = '<div class="stage wide flowstage"><div class="vis"><div class="f"></div></div><div class="t"></div></div>';
  let scene;
  const term = new Term(el.querySelector('.t'), {title:o.title||'student@lab01: ~', interactive:false,
    exec: () => scene && scene.curStep ? scene.curStep.out : '', prompt: o.prompt});
  const flow = new Flow(el.querySelector('.f'), o.nodes, o.wires, o.height||320);
  const ctx = {flow, term};
  scene = new Scene({el, term, intro:o.intro, wait:o.wait, steps:o.steps.map(s => Object.assign({}, s, {
      before: (c) => { if(s.cmd===undefined && s.out){ if(s.out!=='') term.output(s.out); } return s.before ? s.before(Object.assign(c, ctx)) : null; },
      after: s.after ? (r,c) => s.after(r, Object.assign(c, ctx)) : null,
      act: s.act ? (c) => s.act(Object.assign(c, ctx)) : null })),
    reset: () => { flow.clear(); if(o.reset) o.reset(ctx); }});
  return {scene, flow, term};
};

/* ---------------- quizzes ---------------- */
function decorateQuiz(){
  document.querySelectorAll('.quiz').forEach(q => {
    q.querySelectorAll('.opt').forEach(b => b.addEventListener('click', () => {
      if(q.classList.contains('answered')) return;
      q.classList.add('answered');
      q.querySelectorAll('.opt').forEach(o => { if(o.dataset.right!==undefined) o.classList.add('right'); });
      if(b.dataset.right===undefined) b.classList.add('wrong');
    }));
  });
}


/* ---------------- course site: breadcrumb, next lesson, home & day pages ---------------- */
function courseNav(){
  const CO = window.COURSE; const root = document.body.dataset.root;
  if(!CO || root===undefined) return;
  const parts = location.pathname.split('/'); const rel = parts.slice(-2).join('/');
  let day=null, idx=-1;
  if(document.body.dataset.day) day = CO.days.find(d => d.n === +document.body.dataset.day);
  else CO.days.forEach(d => d.blocks.forEach((b,i) => { if(idx<0 && b.href.split('#')[0]===rel){ day=d; idx=i; } }));
  const bar = document.querySelector('.topbar');
  if(bar){
    const crumbs = document.createElement('div'); crumbs.style.display='flex'; crumbs.style.gap='.4rem';
    crumbs.innerHTML = '<a class="btn ghost" href="'+root+'index.html" title="Course home">← Course home</a>' + (day && idx>=0 ? '<a class="btn ghost" href="'+root+day.folder+'/index.html">Day '+day.n+'</a>' : '');
    bar.prepend(crumbs);
  }
  if(day && idx>=0){
    const page = day.blocks[idx].href.split('#')[0];
    const next = day.blocks.slice(idx+1).find(b => b.href.split('#')[0] !== page);
    const main = document.querySelector('main');
    if(main){ const d=document.createElement('section'); d.className='unit'; d.style.textAlign='center';
      d.innerHTML = next ? '<div style="color:var(--muted);font-size:.8rem">Next lesson</div><a class="btn primary" style="font-size:1rem;margin-top:.4rem" href="'+root+next.href+'">'+next.icon+' '+esc(next.title)+' →</a>'
                         : '<div style="color:var(--muted);font-size:.8rem">That was the last lesson of Day '+day.n+'</div><a class="btn primary" style="font-size:1rem;margin-top:.4rem" href="'+root+'index.html">← Back to the course</a>';
      main.appendChild(d); }
  }
}
window.renderHome = function(el){
  const CO = window.COURSE; if(!CO){ el.innerHTML='<p>course-config.js not found.</p>'; return; }
  el.innerHTML = CO.days.map(d => {
    const live = d.status==='live'; const today = CO.today===d.n;
    return '<article class="daycard '+(live?'live':'soon')+(today?' today':'')+'">'+
      '<div class="dhead"><span class="dnum">Day '+d.n+'</span>'+(today?'<span class="pill tday">Today</span>':'')+'<span class="pill '+(live?'plive':'psoon')+'">'+(live?'● Live':'Coming soon')+'</span></div>'+
      '<h3>'+d.icon+' '+esc(d.title)+'</h3><p>'+esc(d.goal)+'</p>'+
      '<ol class="blocks">'+d.blocks.map(b => '<li>'+(live?'<a href="'+b.href+'">':'<span>')+b.icon+' '+esc(b.title)+(live?'</a>':'</span>')+'</li>').join('')+'</ol>'+
      (live?'<a class="btn primary" href="'+d.folder+'/index.html">Open Day '+d.n+' →</a>':'<button class="btn" disabled>Opens on Day '+d.n+'</button>')+
      '</article>';
  }).join('');
};
window.renderDay = function(el){
  const CO = window.COURSE; const n = +document.body.dataset.day; const d = CO && CO.days.find(x => x.n===n);
  if(!d){ el.innerHTML='<p>Day not found in course-config.js</p>'; return; }
  const root = document.body.dataset.root||'';
  document.title = 'Day '+d.n+' · '+d.title;
  const hero = document.getElementById('dayHero');
  if(hero) hero.innerHTML = '<div class="num">DAY '+d.n+' OF '+CO.days.length+'</div><h1>'+d.icon+' '+esc(d.title)+'</h1><p>'+esc(d.goal)+'</p>';
  el.innerHTML = d.blocks.map((b,i) => '<a class="card" href="'+root+b.href+'"><div class="big">'+b.icon+'</div><div class="tag">Part '+(i+1)+'</div><h3>'+esc(b.title)+'</h3><p>'+esc(b.desc||'')+'</p></a>').join('');
};

/* copy button on prompt boxes */
function decoratePrompts(){
  document.querySelectorAll('div.prompt').forEach(p => {
    if(p.dataset.done) return; p.dataset.done = 1;
    const text = p.innerText.trim();
    const b = document.createElement('button'); b.className='copy pcopy'; b.textContent='Copy'; b.title='Copy prompt';
    b.addEventListener('click', () => copy(text, b)); p.appendChild(b);
  });
}
document.addEventListener('DOMContentLoaded', () => { buildChrome(); courseNav(); decorateShell(); decorateSteps(); decorateQuiz(); decoratePrompts(); });
})();
