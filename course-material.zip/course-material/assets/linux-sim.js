/* Linux practice shell (virtual file system) + visuals. Pure JS, offline. */
(function(){
'use strict';
const esc = C.esc;

const ACCESS_LOG = [
'192.168.10.21 - - [23/Nov/2026:09:01:12 +0800] "GET / HTTP/1.1" 200 3380',
'192.168.10.34 - - [23/Nov/2026:09:01:15 +0800] "GET /favicon.ico HTTP/1.1" 404 488',
'192.168.10.21 - - [23/Nov/2026:09:02:40 +0800] "GET /login HTTP/1.1" 200 1820',
'10.0.5.77 - - [23/Nov/2026:09:03:02 +0800] "POST /login HTTP/1.1" 500 612',
'192.168.10.34 - - [23/Nov/2026:09:03:09 +0800] "GET /admin HTTP/1.1" 403 455',
'192.168.10.52 - - [23/Nov/2026:09:04:31 +0800] "GET /grades HTTP/1.1" 200 5120',
'10.0.5.77 - - [23/Nov/2026:09:05:10 +0800] "GET /wp-login.php HTTP/1.1" 404 490',
'10.0.5.77 - - [23/Nov/2026:09:05:11 +0800] "GET /.env HTTP/1.1" 404 490',
'192.168.10.21 - - [23/Nov/2026:09:06:55 +0800] "GET /grades?id=7 HTTP/1.1" 200 5004',
'192.168.10.52 - - [23/Nov/2026:09:07:20 +0800] "POST /grades/save HTTP/1.1" 500 612',
'192.168.10.34 - - [23/Nov/2026:09:08:01 +0800] "GET /css/app.css HTTP/1.1" 200 9001',
'10.0.5.77 - - [23/Nov/2026:09:08:44 +0800] "GET /phpmyadmin HTTP/1.1" 404 492',
'192.168.10.52 - - [23/Nov/2026:09:09:30 +0800] "GET /logout HTTP/1.1" 302 0',
'192.168.10.21 - - [23/Nov/2026:09:10:02 +0800] "GET /grades HTTP/1.1" 200 5120'
].join('\n');
window.ACCESS_LOG = ACCESS_LOG;

function F(c, mode){ return {t:'f', c:c||'', mode:mode||'rw-r--r--'}; }
function D(ch, mode){ return {t:'d', ch:ch||{}, mode:mode||'rwxr-xr-x'}; }
function makeFS(){
  const r = D({
    etc: D({ hostname:F('lab01\n'), 'os-release':F('PRETTY_NAME="Debian GNU/Linux 13 (trixie)"\nNAME="Debian GNU/Linux"\nVERSION_ID="13"\nVERSION_CODENAME=trixie\n'),
             apache2: D({'apache2.conf':F('# Main Apache config\nServerRoot "/etc/apache2"\n'), 'sites-available':D({'000-default.conf':F('<VirtualHost *:80>\n  DocumentRoot /var/www/html\n</VirtualHost>\n')})}),
             passwd: F('root:x:0:0:root:/root:/bin/bash\nstudent:x:1000:1000:Student:/home/student:/bin/bash\nwww-data:x:33:33:www-data:/var/www:/usr/sbin/nologin\n') }),
    home: D({ student: D({
      Documents: D({ 'notes.txt': F('Meeting at 9am\nBring laptop\nAsk about Wi-Fi password\n') }),
      Downloads: D({ 'logo.png': F('(binary image data)') }),
      'todo.txt': F('learn linux\nlearn git\nbuild a laravel app\n'),
      '.bashrc': F('# ~/.bashrc: executed by bash for non-login shells.\nalias ll="ls -l"\n')
    }, 'rwx------') }),
    tmp: D({}, 'rwxrwxrwt'),
    usr: D({ bin: D({ ls:F('(program)','rwxr-xr-x'), cat:F('(program)','rwxr-xr-x'), git:F('(program)','rwxr-xr-x') }) }),
    var: D({ www: D({ html: D({ 'index.html': F('<h1>It works!</h1>\n') }) }),
             log: D({ apache2: D({ 'access.log': F(ACCESS_LOG+'\n','rw-r-----'), 'error.log': F('[php:error] PHP Fatal error: Uncaught PDOException: could not find driver\n[php:error] PHP Warning: file_put_contents(storage/logs/laravel.log): Permission denied\n','rw-r-----') }, 'rwxr-x---') }) })
  });
  (function own(n, o){ n.owner = o; if(n.t==='d') for(const k in n.ch) own(n.ch[k], o); })(r, 'root');
  (function own(n){ n.owner='student'; if(n.t==='d') for(const k in n.ch) own(n.ch[k]); })(r.ch.home.ch.student);
  r.ch.var.ch.log.ch.apache2.group='adm'; r.ch.var.ch.log.ch.apache2.ch['access.log'].group='adm';
  return r;
}

const HOME = ['home','student'];
const sameP = (a,b) => a.length===b.length && a.every((x,i)=>x===b[i]);
const startsP = (a,pre) => pre.length<=a.length && pre.every((x,i)=>x===a[i]);

class Shell {
  constructor(){ this.reset(); this.listeners=[]; }
  reset(){ this.root = makeFS(); this.cwd=[...HOME]; this.prev=null; this.events=[]; this.hist=[]; this.showHidden=false; this.sudoAsked=false; this.expanded=new Set(); if(this.listeners) this.emit(); }
  on(fn){ this.listeners.push(fn); }
  emit(){ this.listeners.forEach(f => f(this)); }
  resolve(p){
    let parts;
    if(p===undefined || p==='') return [...this.cwd];
    if(p.startsWith('/')) parts=[];
    else if(p==='~' || p.startsWith('~/')){ parts=[...HOME]; p=p.slice(1); }
    else parts=[...this.cwd];
    for(const s of p.split('/')){ if(!s || s==='.') continue; if(s==='..'){ parts.pop(); continue; } parts.push(s); }
    return parts;
  }
  node(parts){ let n=this.root; for(const s of parts){ if(!n || n.t!=='d') return null; n = n.ch[s]; } return n||null; }
  abs(parts){ return '/'+parts.join('/'); }
  disp(parts){ if(startsP(parts,HOME)) return '~'+(parts.length>HOME.length?'/'+parts.slice(HOME.length).join('/'):''); return this.abs(parts); }
  canWrite(dirParts){ if(this.sudo) return true; const n=this.node(dirParts); if(!n) return false; return n.owner==='student' || (n.mode||'')[7]==='w'; }
  canRead(parts){ if(this.sudo) return true; const n=this.node(parts); if(!n) return false; if(n.owner==='student') return true; return (n.mode||'')[6]==='r'; }
  prompt(){ const u = 'student'; return '<span class="pr">'+u+'@lab01:<b>'+esc(this.disp(this.cwd))+'</b>$</span>'; }
  ev(kind, parts){ this.events.push({kind, path:this.abs(parts)}); }

  tokenize(s){
    const out=[]; const re=/"([^"]*)"|'([^']*)'|(>>|>|\|)|([^\s"'|>]+)/g; let m;
    while((m=re.exec(s))){ if(m[1]!==undefined) out.push({v:m[1],q:1}); else if(m[2]!==undefined) out.push({v:m[2],q:1}); else if(m[3]) out.push({v:m[3],op:1}); else out.push({v:m[4]}); }
    return out;
  }
  glob(tok){
    if(tok.q || !/[*?]/.test(tok.v)) return [tok.v];
    const i = tok.v.lastIndexOf('/'); const dirS = i>=0 ? tok.v.slice(0,i)||'/' : '.'; const pat = i>=0 ? tok.v.slice(i+1) : tok.v;
    const dir = this.node(this.resolve(dirS)); if(!dir || dir.t!=='d') return [tok.v];
    const re = new RegExp('^'+pat.replace(/[.+^${}()|[\]\\]/g,'\\$&').replace(/\*/g,'.*').replace(/\?/g,'.')+'$');
    const m = Object.keys(dir.ch).filter(n => re.test(n) && (pat.startsWith('.') || !n.startsWith('.'))).sort();
    return m.length ? m.map(n => i>=0 ? (dirS==='/'?'':dirS)+'/'+n : n) : [tok.v];
  }

  exec(line){
    this.events = []; this.hist.push(line);
    const toks = this.tokenize(line.trim());
    const stages=[]; let cur=[]; let redir=null;
    for(let k=0;k<toks.length;k++){
      const t=toks[k];
      if(t.op && t.v==='|'){ stages.push(cur); cur=[]; }
      else if(t.op){ redir = {mode:t.v, file:(toks[k+1]||{}).v}; k++; }
      else cur.push(t);
    }
    stages.push(cur);
    const lines=[]; let stdin=null; let last=null;
    for(let si=0; si<stages.length; si++){
      let args = stages[si]; this.sudo=false;
      if(args.length && args[0].v==='sudo'){ this.sudo=true; args=args.slice(1); if(!this.sudoAsked){ lines.push({t:'[sudo] password for student: ••••••', c:'dim'}); this.sudoAsked=true; } }
      if(!args.length) break;
      const name = args[0].v; const argv = []; args.slice(1).forEach(a => argv.push(...this.glob(a)));
      const fn = this.cmds[name];
      let r;
      if(!fn){
        const real = {apt:1,'apt-get':1,systemctl:1,git:1,journalctl:1,curl:1,ss:1,ip:1,ping:1,find:1,locate:1,chown:1,usermod:1,top:1,htop:1,ps:1,kill:1,php:1,mysql:1,mariadb:1,man:1,nano:1,vim:1,vi:1,less:1,more:1,df:1,du:1,free:1};
        r = real[name] ? {err:'ℹ  `'+name+'` is real but not part of this practice shell. Try it on your Debian terminal.', info:true} : {err:'bash: '+name+': command not found'};
      } else r = fn.call(this, argv, stdin) || {};
      if(r.err) lines.push({t:r.err, c:r.info?'hl':'err'});
      if(r.clear) return {clear:true};
      stdin = r.out!==undefined ? r.out : '';
      last = r;
    }
    this.sudo=false;
    if(redir && last){
      if(!redir.file){ lines.push({t:'bash: syntax error near unexpected token `newline\'', c:'err'}); }
      else {
        const p=this.resolve(redir.file); const dirP=p.slice(0,-1); const dir=this.node(dirP);
        if(!dir || dir.t!=='d') lines.push({t:'bash: '+redir.file+': No such file or directory', c:'err'});
        else if(!this.canWrite(dirP)){ lines.push({t:'bash: '+redir.file+': Permission denied', c:'err'}); this.ev('denied', dirP); }
        else { const ex = dir.ch[p.at(-1)]; const text = (stdin||'') + ((stdin||'').endsWith('\n')||!stdin?'':'\n');
          if(ex && ex.t==='d') lines.push({t:'bash: '+redir.file+': Is a directory', c:'err'});
          else { if(redir.mode==='>>' && ex) ex.c += text; else { dir.ch[p.at(-1)] = Object.assign(F(text), {owner:'student'}); } this.ev('new', p); } }
      }
    } else if(last){
      if(last.html && stages.length===1) lines.push({html:last.html});
      else if(last.out){ last.out.replace(/\n$/,'').split('\n').forEach(t => lines.push({t})); }
    }
    this.emit();
    return lines;
  }
}

function lsLong(name, n){
  const typ = n.t==='d'?'d':'-';
  const size = n.t==='d' ? 4096 : (n.c||'').length;
  const grp = n.group || n.owner;
  return typ+n.mode+' '+(n.t==='d'?2:1)+' '+(n.owner||'root').padEnd(7)+' '+(grp||'root').padEnd(7)+' '+String(size).padStart(5)+' Nov 23 09:00 '+name;
}
function colorName(name, n){ return n.t==='d' ? '<span class="blue"><b>'+esc(name)+'</b></span>' : (n.mode&&n.mode[2]==='x' ? '<span class="ok">'+esc(name)+'</span>' : esc(name)); }
function flags(argv){ const f=new Set(), rest=[]; let opts={}; for(let i=0;i<argv.length;i++){ const a=argv[i]; if(/^-\d+$/.test(a)){ opts.n=+a.slice(1); } else if(a==='-n' && /^\d+$/.test(argv[i+1]||'')){ opts.n=+argv[++i]; } else if(/^--?[a-zA-Z]/.test(a) && a.length>1){ if(a.startsWith('--')) f.add(a); else a.slice(1).split('').forEach(c=>f.add(c)); } else rest.push(a); } return {f, rest, opts}; }
function readInputs(sh, files, stdin, cmd){
  if(!files.length) return {text: stdin||''};
  let text=''; const errs=[];
  for(const p of files){ const parts=sh.resolve(p); const n=sh.node(parts);
    if(!n) errs.push(cmd+': '+p+': No such file or directory');
    else if(n.t==='d') errs.push(cmd+': '+p+': Is a directory');
    else if(!sh.canRead(parts) || !sh.canRead(parts.slice(0,-1))){ errs.push(cmd+': '+p+': Permission denied'); sh.ev('denied', parts); }
    else text += n.c; }
  return {text, err: errs.join('\n')||undefined};
}

Shell.prototype.cmds = {
  pwd(){ return {out: this.abs(this.cwd)+'\n'}; },
  whoami(){ return {out: (this.sudo?'root':'student')+'\n'}; },
  hostname(){ return {out:'lab01\n'}; },
  date(){ return {out: new Date().toString()+'\n'}; },
  clear(){ return {clear:true}; },
  history(){ return {out: this.hist.map((h,i)=>String(i+1).padStart(5)+'  '+h).join('\n')+'\n'}; },
  echo(argv){ return {out: argv.join(' ')+'\n'}; },
  help(){ return {out:'Practice shell commands:\n  pwd ls cd mkdir touch cat echo cp mv rm rmdir tree\n  head tail grep wc sort uniq chmod whoami history clear\nUse sudo in front to act as root.  Pipes | and > >> work.\n'}; },
  ls(argv){
    const {f, rest} = flags(argv); if(f.has('a')) this.showHidden=true;
    const targets = rest.length? rest : ['.'];
    let html=[], out=[];
    for(const p of targets){
      const parts=this.resolve(p); const n=this.node(parts);
      if(!n){ return {err:"ls: cannot access '"+p+"': No such file or directory"}; }
      if(n.t==='f'){ out.push(f.has('l')? lsLong(p,n) : p); html.push(f.has('l')? esc(lsLong(p,n)) : esc(p)); continue; }
      if(!this.canRead(parts)){ this.ev('denied', parts); return {err:"ls: cannot open directory '"+p+"': Permission denied"}; }
      this.expanded.add(this.abs(parts)); this.ev('listed', parts);
      let names = Object.keys(n.ch).sort((a,b)=>a.replace(/^\./,'').localeCompare(b.replace(/^\./,'')));
      if(!f.has('a')) names = names.filter(x => !x.startsWith('.'));
      if(targets.length>1){ out.push(p+':'); html.push(esc(p)+':'); }
      if(f.has('l')){
        out.push('total '+names.length*4); html.push('total '+names.length*4);
        if(f.has('a')){ [['.',n],['..',this.node(parts.slice(0,-1))||n]].forEach(([nm,nd])=>{ out.push(lsLong(nm,nd)); html.push(esc(lsLong(nm,nd).slice(0,-nm.length))+colorName(nm,nd)); }); }
        names.forEach(x => { const c=n.ch[x]; const l=lsLong(x,c); out.push(l); html.push(esc(l.slice(0,-x.length))+colorName(x,c)); });
      } else {
        const all = (f.has('a')?['.','..']:[]).concat(names);
        out.push(all.join('  ')); html.push(all.map(x => colorName(x, x==='.'||x==='..'?{t:'d'}:n.ch[x])).join('  '));
      }
    }
    return {out: out.join('\n')+'\n', html: html.join('<br>')};
  },
  cd(argv){
    let p = argv[0];
    if(p===undefined || p==='~'){ p='~'; }
    if(p==='-'){ if(!this.prev) return {err:'bash: cd: OLDPWD not set'}; const t=this.prev; this.prev=this.cwd; this.cwd=t; return {out:this.abs(this.cwd)+'\n'}; }
    const parts=this.resolve(p); const n=this.node(parts);
    if(!n) return {err:'bash: cd: '+p+': No such file or directory'};
    if(n.t!=='d') return {err:'bash: cd: '+p+': Not a directory'};
    if(!this.sudo && n.owner!=='student' && n.mode[8]!=='x'){ this.ev('denied',parts); return {err:'bash: cd: '+p+': Permission denied'}; }
    this.prev=this.cwd; this.cwd=parts; return {};
  },
  mkdir(argv){
    const {f, rest}=flags(argv); if(!rest.length) return {err:'mkdir: missing operand'};
    const errs=[];
    for(const p of rest){
      const parts=this.resolve(p);
      if(f.has('p')){ for(let i=1;i<=parts.length;i++){ const sub=parts.slice(0,i); const n=this.node(sub); if(n) continue; if(!this.canWrite(sub.slice(0,-1))){ errs.push("mkdir: cannot create directory '"+this.abs(sub)+"': Permission denied"); this.ev('denied',sub.slice(0,-1)); break; } this.node(sub.slice(0,-1)).ch[sub.at(-1)] = Object.assign(D(), {owner:this.sudo?'root':'student'}); this.ev('new',sub); this.expanded.add(this.abs(sub.slice(0,-1))); } continue; }
      const dir=this.node(parts.slice(0,-1));
      if(this.node(parts)){ errs.push("mkdir: cannot create directory '"+p+"': File exists"); continue; }
      if(!dir){ errs.push("mkdir: cannot create directory '"+p+"': No such file or directory"); continue; }
      if(!this.canWrite(parts.slice(0,-1))){ errs.push("mkdir: cannot create directory '"+p+"': Permission denied"); this.ev('denied',parts.slice(0,-1)); continue; }
      dir.ch[parts.at(-1)] = Object.assign(D(), {owner:this.sudo?'root':'student'}); this.ev('new',parts); this.expanded.add(this.abs(parts.slice(0,-1)));
    }
    return {err: errs.join('\n')||undefined};
  },
  touch(argv){
    if(!argv.length) return {err:'touch: missing file operand'};
    const errs=[];
    for(const p of argv){ const parts=this.resolve(p); const dir=this.node(parts.slice(0,-1));
      if(this.node(parts)){ this.ev('listed',parts); continue; }
      if(!dir) { errs.push("touch: cannot touch '"+p+"': No such file or directory"); continue; }
      if(!this.canWrite(parts.slice(0,-1))){ errs.push("touch: cannot touch '"+p+"': Permission denied"); this.ev('denied',parts.slice(0,-1)); continue; }
      dir.ch[parts.at(-1)] = Object.assign(F(''), {owner:this.sudo?'root':'student'}); this.ev('new',parts); this.expanded.add(this.abs(parts.slice(0,-1))); }
    return {err: errs.join('\n')||undefined};
  },
  cat(argv, stdin){ const r=readInputs(this, argv.filter(a=>!a.startsWith('-')), stdin, 'cat'); argv.forEach(a=>{ const p=this.resolve(a); if(this.node(p)) this.ev('listed',p); }); return {out:r.text, err:r.err}; },
  head(argv, stdin){ const {rest,opts}=flags(argv); const r=readInputs(this, rest, stdin, 'head'); const n=opts.n||10; return {out: r.text.split('\n').filter((l,i,a)=>!(i===a.length-1&&l==='')).slice(0,n).join('\n')+'\n', err:r.err}; },
  tail(argv, stdin){ const {f,rest,opts}=flags(argv); const r=readInputs(this, rest, stdin, 'tail'); const n=opts.n||10; const ls=r.text.split('\n'); if(ls.at(-1)==='') ls.pop(); let out=ls.slice(-n).join('\n')+'\n'; if(f.has('f')) out += '(tail -f keeps watching for new lines. Press Ctrl+C to stop. Try it for real on /var/log/apache2/access.log)\n'; return {out, err:r.err}; },
  grep(argv, stdin){
    const {f,rest}=flags(argv); if(!rest.length) return {err:'Usage: grep [OPTION]... PATTERNS [FILE]...'};
    const pat=rest[0], files=rest.slice(1); let re; try{ re=new RegExp(pat, f.has('i')?'i':''); }catch(e){ re=new RegExp(pat.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), f.has('i')?'i':''); }
    const r=readInputs(this, files, stdin, 'grep');
    const ls=r.text.split('\n'); if(ls.at(-1)==='') ls.pop();
    const hits=[]; ls.forEach((l,i)=>{ if(re.test(l) !== f.has('v')) hits.push(f.has('n')?(i+1)+':'+l:l); });
    if(f.has('c')) return {out:hits.length+'\n', err:r.err};
    return {out: hits.length? hits.join('\n')+'\n' : '', err:r.err};
  },
  wc(argv, stdin){ const {f,rest}=flags(argv); const r=readInputs(this, rest, stdin, 'wc'); const t=r.text; const l=(t.match(/\n/g)||[]).length, w=(t.trim().split(/\s+/).filter(Boolean)).length, c=t.length; const name=rest[0]?' '+rest[0]:''; if(f.has('l')) return {out:l+name+'\n', err:r.err}; if(f.has('w')) return {out:w+name+'\n'}; return {out:'  '+l+'  '+w+' '+c+name+'\n', err:r.err}; },
  sort(argv, stdin){ const {f,rest}=flags(argv); const r=readInputs(this, rest, stdin, 'sort'); const ls=r.text.split('\n').filter(x=>x!==''); ls.sort(f.has('n')?((a,b)=>parseFloat(a)-parseFloat(b)):undefined); if(f.has('r')) ls.reverse(); return {out:ls.join('\n')+'\n'}; },
  uniq(argv, stdin){ const {f}=flags(argv); const ls=(stdin||'').split('\n').filter(x=>x!==''); const out=[]; let prev=null, n=0; ls.concat([null]).forEach(l=>{ if(l===prev){n++;return;} if(prev!==null) out.push(f.has('c')?String(n).padStart(7)+' '+prev:prev); prev=l; n=1; }); return {out:out.join('\n')+'\n'}; },
  rm(argv){
    const {f,rest}=flags(argv); if(!rest.length) return {err:'rm: missing operand'};
    const errs=[];
    for(const p of rest){ const parts=this.resolve(p); const n=this.node(parts);
      if(!n){ if(!f.has('f')) errs.push("rm: cannot remove '"+p+"': No such file or directory"); continue; }
      if(n.t==='d' && !(f.has('r')||f.has('R'))){ errs.push("rm: cannot remove '"+p+"': Is a directory"); continue; }
      if(!this.canWrite(parts.slice(0,-1))){ errs.push("rm: cannot remove '"+p+"': Permission denied"); this.ev('denied',parts.slice(0,-1)); continue; }
      if(startsP(this.cwd, parts)) this.cwd = parts.slice(0,-1);
      delete this.node(parts.slice(0,-1)).ch[parts.at(-1)]; this.ev('removed', parts.slice(0,-1)); }
    return {err: errs.join('\n')||undefined};
  },
  rmdir(argv){ const errs=[]; for(const p of argv){ const parts=this.resolve(p); const n=this.node(parts); if(!n){ errs.push("rmdir: failed to remove '"+p+"': No such file or directory"); continue;} if(n.t!=='d'){ errs.push("rmdir: failed to remove '"+p+"': Not a directory"); continue;} if(Object.keys(n.ch).length){ errs.push("rmdir: failed to remove '"+p+"': Directory not empty"); continue;} delete this.node(parts.slice(0,-1)).ch[parts.at(-1)]; this.ev('removed',parts.slice(0,-1)); } return {err:errs.join('\n')||undefined}; },
  mv(argv){ return this.copyMove(argv, true); },
  cp(argv){ return this.copyMove(argv, false); },
  chmod(argv){
    const [mode, ...files] = argv; if(!mode||!files.length) return {err:'chmod: missing operand'};
    for(const p of files){ const parts=this.resolve(p); const n=this.node(parts); if(!n) return {err:"chmod: cannot access '"+p+"': No such file or directory"};
      if(!this.sudo && n.owner!=='student'){ this.ev('denied',parts); return {err:"chmod: changing permissions of '"+p+"': Operation not permitted"}; }
      const nm = applyMode(n.mode, mode); if(nm===null) return {err:"chmod: invalid mode: '"+mode+"'"}; n.mode = nm; this.ev('new',parts); }
    return {};
  },
  tree(argv){
    const parts=this.resolve(argv[0]||'.'); const n=this.node(parts); if(!n||n.t!=='d') return {err:(argv[0]||'.')+' [error opening dir]'};
    const out=[argv[0]||'.']; let dirs=0, files=0;
    (function walk(d, pre){ const ks=Object.keys(d.ch).filter(k=>!k.startsWith('.')).sort(); ks.forEach((k,i)=>{ const last=i===ks.length-1; const c=d.ch[k]; out.push(pre+(last?'└── ':'├── ')+k); if(c.t==='d'){ dirs++; walk(c, pre+(last?'    ':'│   ')); } else files++; }); })(n,'');
    out.push('', dirs+' directories, '+files+' files');
    return {out: out.join('\n')+'\n'};
  }
};
Shell.prototype.copyMove = function(argv, move){
  const cmd = move?'mv':'cp'; const {f,rest}=flags(argv);
  if(rest.length<2) return {err: cmd+': missing destination file operand'};
  const dst = rest.pop(); const dstP=this.resolve(dst); const dstN=this.node(dstP);
  const errs=[];
  for(const s of rest){
    const sP=this.resolve(s); const sN=this.node(sP);
    if(!sN){ errs.push(cmd+": cannot stat '"+s+"': No such file or directory"); continue; }
    if(!move && sN.t==='d' && !(f.has('r')||f.has('R'))){ errs.push("cp: -r not specified; omitting directory '"+s+"'"); continue; }
    let tP = (dstN && dstN.t==='d') ? dstP.concat(sP.at(-1)) : dstP;
    const tDir = this.node(tP.slice(0,-1));
    if(!tDir || tDir.t!=='d'){ errs.push(cmd+": cannot create '"+dst+"': No such file or directory"); continue; }
    if(!this.canWrite(tP.slice(0,-1)) || (move && !this.canWrite(sP.slice(0,-1)))){ errs.push(cmd+": cannot "+(move?'move':'create')+" '"+s+"': Permission denied"); this.ev('denied', tP.slice(0,-1)); continue; }
    if(startsP(tP, sP)){ errs.push(cmd+": cannot "+(move?'move':'copy')+" a directory, '"+s+"', into itself"); continue; }
    const copyN = JSON.parse(JSON.stringify(sN));
    if(!move) (function own(n,o){ n.owner=o; if(n.t==='d') for(const k in n.ch) own(n.ch[k],o); })(copyN, this.sudo?'root':'student');
    tDir.ch[tP.at(-1)] = copyN;
    if(move){ delete this.node(sP.slice(0,-1)).ch[sP.at(-1)]; if(startsP(this.cwd, sP)) this.cwd = tP.concat(this.cwd.slice(sP.length)); }
    this.ev('new', tP); this.expanded.add(this.abs(tP.slice(0,-1)));
  }
  return {err: errs.join('\n')||undefined};
};

function applyMode(cur, mode){
  if(/^[0-7]{3}$/.test(mode)){ return mode.split('').map(d => { d=+d; return (d&4?'r':'-')+(d&2?'w':'-')+(d&1?'x':'-'); }).join(''); }
  const m = mode.match(/^([ugoa]*)([+\-=])([rwx]+)$/); if(!m) return null;
  const who = (m[1]||'a').replace('a','ugo'); const arr = cur.split('');
  for(const w of who){ const base = {u:0,g:3,o:6}[w];
    ['r','w','x'].forEach((b,i)=>{ const has = m[3].includes(b);
      if(m[2]==='+' && has) arr[base+i]=b; if(m[2]==='-' && has) arr[base+i]='-'; if(m[2]==='=') arr[base+i]= has? b : '-'; }); }
  return arr.join('');
}
window.applyMode = applyMode;
window.Shell = Shell;

/* ---------------- File-system tree visual ---------------- */
class FSVis {
  constructor(el, sh, opt={}){
    this.el=el; this.sh=sh; this.opt=opt; el.classList.add('fstree');
    this.here = document.createElement('div'); this.here.className='here'; this.here.innerHTML='<span>📍 you are here</span>';
    sh.on(() => this.render()); this.render();
  }
  visible(){
    const sh=this.sh, rows=[];
    const cwdA = sh.abs(sh.cwd);
    const walk = (n, parts, depth) => {
      const a = sh.abs(parts);
      rows.push({n, parts, depth, a});
      if(n.t!=='d') return;
      const open = parts.length===0 || cwdA===a || cwdA.startsWith(a+'/') || sh.expanded.has(a) || startsP(parts, HOME) || (this.opt.open||[]).some(o => o===a || o.startsWith(a+'/'));
      n._open = open;
      if(!open) return;
      Object.keys(n.ch).sort((x,y)=>{ const dx=n.ch[x].t==='d', dy=n.ch[y].t==='d'; return dx===dy ? x.replace(/^\./,'').localeCompare(y.replace(/^\./,'')) : (dx?-1:1); })
        .filter(k => sh.showHidden || !k.startsWith('.')).forEach(k => walk(n.ch[k], parts.concat(k), depth+1));
    };
    walk(sh.root, [], 0);
    return rows;
  }
  render(){
    const sh=this.sh; const rows=this.visible(); const evs = sh.events || [];
    const cwdA = sh.abs(sh.cwd);
    const html = rows.map(r => {
      const nm = r.parts.length? r.parts.at(-1) : '/';
      const cls = ['row', r.n.t==='d'?'dir':'file'];
      if(r.a===cwdA) cls.push('cwd');
      evs.forEach(e => {
        if(e.kind==='new' && e.path===r.a) cls.push('flash');
        if(e.kind==='denied' && e.path===r.a) cls.push('denied');
        if(e.kind==='listed' && (e.path===r.a || (r.a.startsWith(e.path+'/') && r.a.split('/').length===e.path.split('/').length+(e.path==='/'?0:1)))) cls.push('listed');
      });
      const icon = r.n.t==='d' ? (r.n._open?'📂':'📁') : (r.n.mode&&r.n.mode[2]==='x'?'⚙️':'📄');
      const own = r.n.owner==='root' && r.depth>0 && this.opt.owners!==false ? '<span class="dim" style="font-size:.6rem;color:var(--muted)">root</span>' : '';
      return '<div class="'+cls.join(' ')+'" data-a="'+esc(r.a)+'" style="padding-left:'+(r.depth*1.1+.3)+'rem"><span class="ic">'+icon+'</span><span class="nm">'+esc(nm)+(r.n.t==='d'&&r.depth?'/':'')+'</span>'+own+'</div>';
    }).join('');
    this.el.innerHTML = html; this.el.appendChild(this.here);
    const cur = this.el.querySelector('.row.cwd');
    if(cur){ const nm=cur.querySelector('.nm'); this.here.style.top = cur.offsetTop+'px'; this.here.style.left = (nm.offsetLeft+nm.offsetWidth+ (cur.children[2]?40:10))+'px'; }
    // keep "listed" highlight briefly
    clearTimeout(this._t); this._t = setTimeout(() => this.el.querySelectorAll('.row.listed').forEach(x=>x.classList.remove('listed')), 2200);
  }
}
window.FSVis = FSVis;

/* convenience: build a shell + terminal + tree, optionally with a scripted scene */
window.makeShellLab = function(rootEl, opt={}){
  const sh = new Shell();
  if(opt.setup) opt.setup(sh);
  rootEl.innerHTML = '<div class="stage"><div class="t"></div><div class="vis"><div class="legend">📂 open folder · 📄 file · <span style="color:var(--ok)">■</span> where you are · <span style="color:var(--warn)">■</span> just listed / created</div><div class="tree"></div></div></div>';
  const term = new Term(rootEl.querySelector('.t'), {title:'Practice shell (safe: nothing here touches your real machine)', exec: l => sh.exec(l), prompt: () => sh.prompt(), banner: opt.banner || 'Type commands here, or press ▶ Play. Type help for the list.' });
  const vis = new FSVis(rootEl.querySelector('.tree'), sh, opt.vis||{});
  term.refreshPrompt();
  sh.on(() => term.refreshPrompt());
  let scene=null;
  if(opt.steps){
    scene = new Scene({ el: rootEl, term, steps: opt.steps, intro: opt.intro, wait: opt.wait,
      reset: () => { sh.reset(); if(opt.setup) opt.setup(sh); sh.emit(); term.refreshPrompt(); } });
  } else { rootEl.classList.add('scene'); }
  return {sh, term, vis, scene};
};

/* ---------------- pipeline visualiser ---------------- */
window.makePipeline = function(el, files){
  el.innerHTML = '<div style="display:flex;gap:.5rem;flex-wrap:wrap;align-items:center"><input class="pipe-in" style="flex:1 1 380px;font:600 .9rem var(--mono);padding:.55rem .8rem;border-radius:10px;border:2px solid var(--line);background:var(--term-bg);color:var(--term-ink)" spellcheck="false"><button class="btn primary run">▶ Run pipeline</button></div><div class="presets" style="margin:.5rem 0;display:flex;gap:.4rem;flex-wrap:wrap"></div><div class="pipeline"></div>';
  const input = el.querySelector('.pipe-in'), out = el.querySelector('.pipeline');
  const presets = ['cat access.log | grep 404','cat access.log | grep 404 | wc -l','grep -v " 200 " access.log | cut -d" " -f1 | sort | uniq -c','cut -d" " -f9 access.log | sort | uniq -c | sort -rn','grep POST access.log | grep 500'];
  presets.forEach(p => { const b=document.createElement('button'); b.className='btn'; b.style.fontFamily='var(--mono)'; b.style.fontSize='.62rem'; b.textContent=p; b.onclick=()=>{input.value=p; run();}; el.querySelector('.presets').appendChild(b); });
  const sh = new Shell(); sh.cwd = ['tmp']; Object.entries(files).forEach(([k,v]) => sh.node(['tmp']).ch[k] = Object.assign(F(v+'\n'),{owner:'student'}));
  sh.cmds = Object.assign({}, Shell.prototype.cmds, {
    cut(argv, stdin){ let d='\t', fld=1, rest=[]; for(let i=0;i<argv.length;i++){ const a=argv[i]; if(a.startsWith('-d')) d = a.length>2? a.slice(2) : argv[++i]; else if(a.startsWith('-f')) fld = +(a.length>2? a.slice(2) : argv[++i]); else rest.push(a); }
      const r=readInputs(this, rest, stdin, 'cut'); return {out: r.text.split('\n').filter(x=>x!=='').map(l => l.split(d)[fld-1]||'').join('\n')+'\n', err:r.err}; }
  });
  async function run(){
    const stages = input.value.split('|').map(s=>s.trim()).filter(Boolean);
    out.innerHTML=''; let stdin=null;
    for(let i=0;i<stages.length;i++){
      const toks = sh.tokenize(stages[i]); const name = toks[0]&&toks[0].v; const argv=[]; toks.slice(1).forEach(t=>argv.push(...sh.glob(t)));
      const fn = sh.cmds[name]; const r = fn ? (fn.call(sh, argv, stdin)||{}) : {err:name+': not available in this demo'};
      const text = r.err ? r.err : (r.out||'');
      if(i>0){ const a=document.createElement('div'); a.className='pipe-arrow'; a.textContent='➜'; out.appendChild(a); }
      const box=document.createElement('div'); box.className='stagebox';
      const lines = text.replace(/\n$/,'').split('\n').filter((x,j,arr)=>!(arr.length===1&&x===''));
      const pat = name==='grep' ? argv.filter(a=>!a.startsWith('-'))[0] : null;
      box.innerHTML = '<h4>'+esc(stages[i])+'</h4><div class="lines">'+lines.map((l,j)=>'<div style="animation-delay:'+(j*40)+'ms">'+(pat&&!argv.includes('-v')?esc(l).split(esc(pat)).join('<mark>'+esc(pat)+'</mark>'):esc(l))+'</div>').join('')+'</div><div class="count">'+lines.length+' line'+(lines.length===1?'':'s')+' out</div>';
      out.appendChild(box);
      stdin = r.out||'';
      await C.sleep(450);
    }
  }
  input.value = presets[1];
  el.querySelector('.run').onclick = run;
  input.addEventListener('keydown', e => { if(e.key==='Enter') run(); });
  run();
};

/* ---------------- permission bits widget ---------------- */
window.makePerms = function(el){
  el.innerHTML = '<div class="permgrid"><div></div><div class="hd">read r=4</div><div class="hd">write w=2</div><div class="hd">execute x=1</div><div class="hd">octal</div>'+
    ['u','g','o'].map((w,i)=>'<div class="who">'+['👤 user (owner)','👥 group','🌍 others'][i]+'<small>'+['the file\'s owner','members of the file\'s group','everybody else'][i]+'</small></div>'+
      ['r','w','x'].map(b=>'<button class="bit '+b+'" data-w="'+w+'" data-b="'+b+'">'+b+'</button>').join('')+'<div class="octal" data-o="'+w+'">0</div>').join('')+
    '</div><div style="margin-top:.8rem;display:flex;flex-wrap:wrap;gap:1rem;align-items:center"><div><div class="dim" style="font-size:.7rem;color:var(--muted)">ls -l shows</div><div class="bigline sym"></div></div><div><div class="dim" style="font-size:.7rem;color:var(--muted)">command to set it</div><div class="bigline cmd"></div></div></div>'+
    '<div style="margin-top:.5rem;display:flex;gap:.4rem;flex-wrap:wrap" class="presets"></div><div class="callout meaning" style="margin-top:.6rem"></div>';
  let mode = 'rw-r--r--';
  const presets = [['644','normal file: owner edits, others read'],['755','program or folder everyone can enter'],['600','private file (SSH key, .env)'],['700','private folder'],['775','shared team folder (group can write)'],['777','⚠️ everyone can do everything (never on a server)']];
  presets.forEach(([m,d]) => { const b=document.createElement('button'); b.className='btn'; b.innerHTML='<b style="font-family:var(--mono)">'+m+'</b> '+d; b.onclick=()=>{ mode=applyMode(mode,m); paint(); }; el.querySelector('.presets').appendChild(b); });
  el.querySelectorAll('.bit').forEach(b => b.onclick = () => { const i={u:0,g:3,o:6}[b.dataset.w] + 'rwx'.indexOf(b.dataset.b); const a=mode.split(''); a[i] = a[i]==='-'? b.dataset.b : '-'; mode=a.join(''); paint(); });
  function oct(){ return [0,3,6].map(i => (mode[i]!=='-'?4:0)+(mode[i+1]!=='-'?2:0)+(mode[i+2]!=='-'?1:0)).join(''); }
  function paint(){
    el.querySelectorAll('.bit').forEach(b => { const i={u:0,g:3,o:6}[b.dataset.w] + 'rwx'.indexOf(b.dataset.b); b.classList.toggle('on', mode[i]!=='-'); });
    const o=oct(); ['u','g','o'].forEach((w,i)=>el.querySelector('[data-o="'+w+'"]').textContent=o[i]);
    el.querySelector('.sym').textContent = '-'+mode+'  report.txt';
    el.querySelector('.cmd').textContent = 'chmod '+o+' report.txt';
    const m = el.querySelector('.meaning');
    const say = (k)=>{ const r=mode[k]!=='-', w=mode[k+1]!=='-', x=mode[k+2]!=='-'; const a=[]; if(r)a.push('read'); if(w)a.push('change'); if(x)a.push('run'); return a.length? 'can '+a.join(', ') : 'can do <b>nothing</b>'; };
    m.innerHTML = '👤 Owner '+say(0)+' · 👥 Group '+say(3)+' · 🌍 Others '+say(6) + (o==='777'?'<br><b style="color:var(--bad)">On a web server this means any compromised process can rewrite your code. Fix the owner/group instead.</b>':'');
  }
  paint();
};
})();
