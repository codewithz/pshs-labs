/* =====================================================================
   COURSE CONFIG: the only file you edit to publish a day.

   To publish a day:   upload its folder (e.g. day2/), then change
                        status: "soon"  →  status: "live"
   To move a lesson:    move its .html file to the other day's folder,
                        then cut/paste its line into that day's "blocks"
                        and fix the folder name in its href.
                        (Example: Git branching → Day 3: move
                         day1/branching.html to day3/branching.html.)
   Block order here = order shown on the home page and the day page,
   and the "Next lesson" button at the bottom of every lesson.
   ===================================================================== */
window.COURSE = {
  title: "Full-Stack Web Development with LAMP & Laravel",
  subtitle: "5-day hands-on training · Philippine Science High School System",
  dates: "23 to 27 November 2026",

  /* Day to highlight as "Today" on the home page (0 = none). */
  today: 4,

  /* bashcrawl game (Day 1 finale). The tarball is bundled with the site. */
  bashcrawl: {
    gitUrl: "https://gitlab.com/slackermedia/bashcrawl.git",
    tarball: "day1/downloads/bashcrawl.tar.gz"
  },

  days: [
    { n: 1, folder: "day1", status: "live", icon: "🐧",
      title: "Linux, Apache & Git",
      goal: "Drive a Debian server from the terminal, run your own Apache web server, and work like a team with Git.",
      blocks: [
        { title: "Linux on Debian", icon: "🐧", href: "day1/linux.html",
          desc: "Terminal, moving around, files, reading logs with grep and pipes, permissions and sudo." },
        { title: "Apache: your own web server", icon: "🪶", href: "day1/linux.html#l5",
          desc: "apt, systemctl, install Apache, visit your neighbour's server, watch live logs." },
        { title: "Git basics", icon: "🌳", href: "day1/git.html",
          desc: "The three areas, commits, history and undo, push and pull with a teammate." },
        { title: "Git branching", icon: "🌿", href: "day1/branching.html",
          desc: "Branches as sticky notes, switch, merge, a table branching drill." },
        { title: "Finale: bashcrawl", icon: "🔥", href: "day1/bashcrawl.html",
          desc: "Escape a dungeon using only the terminal. Table challenge." }
      ] },

    { n: 2, folder: "day2", status: "live", icon: "🗄️",
      title: "MariaDB, Claude Code & PHP intro",
      goal: "Design and query a database, start building with Claude Code, and write your first PHP.",
      blocks: [
        { title: "SQL practice: the report card", icon: "🧩", href: "day2/sql-exercises.html", desc: "Fill-in-the-blank SQL checked in your browser, from CREATE TABLE to the JOIN that rebuilds a report card." },
        { title: "Claude Code in VS Code", icon: "🤖", href: "day2/claude-code.html", desc: "Ask, plan, approve and review with Git: an AI coding agent on your report-card project." }
        /* No pages yet. Add back when the files exist:
        { title: "MariaDB / MySQL", icon: "🗄️", href: "day2/mariadb.html", desc: "Databases, tables, SQL queries, users and privileges." },
        { title: "PHP intro", icon: "🐘", href: "day2/php-intro.html", desc: "First PHP page served by Apache, talking to MariaDB." } */
      ] },

    { n: 3, folder: "day3", status: "live", icon: "🐘",
      title: "Claude Code, PHP & Laravel",
      goal: "Steer Claude Code with CLAUDE.md, refresh your PHP, see how Composer and Laravel fit together, then build a Laravel report card app one prompt at a time.",
      blocks: [
        { title: "Claude Code and CLAUDE.md", icon: "🤖", href: "day3/claude-start.html", desc: "Build the same Vanilla JS page with and without CLAUDE.md, then split rules between front end and back end." },
        { title: "PHP refresher", icon: "🐘", href: "day3/php-oop.html", desc: "Variables, arrays, functions, PHP in a web page, then the classes and namespaces Laravel is built from." },
        { title: "How the pieces fit", icon: "🗺️", href: "day3/architecture.html", desc: "The full stack, Composer, and Laravel as a restaurant: host, sitting area, kitchen, pantry, plating." },
        { title: "Laravel with Claude Code", icon: "🚀", href: "day3/laravel.html", desc: "Understand, build and check prompts, with the expected code for every step: migrations, models, a service, controllers and Blade." },
        { title: "Windows setup: Laravel + MariaDB", icon: "🪟", href: "day3/windows-setup.html", desc: "Run the Day 3 report card app on your own Windows PC: XAMPP + Composer, Laravel Herd, or WSL2 Debian, plus MariaDB and Claude Code." }
      ] },

    { n: 4, folder: "day4", status: "live", icon: "🔌",
      title: "APIs, Postman, Claude agents & skills, CI/CD, login & AWS",
      goal: "Build a secured JSON API for the report card app and test it with Postman, give Claude Code a reviewer agent and a recipe skill, run your tests on GitHub, add a web login, then watch the app deploy to AWS.",
      blocks: [
        { title: "APIs from zero", icon: "📡", href: "day4/api-basics.html", desc: "Why APIs exist, HTTP requests, verbs, status codes and naming, a small JSON API in plain PHP, then Postman." },
        { title: "JSON API, secured", icon: "🔌", href: "day4/api.html", desc: "Token login with Sanctum, a Policy per teacher, the report card as JSON, and a grade update that can't be abused." },
        { title: "Test the API with Postman", icon: "📮", href: "day4/postman.html", desc: "Test scripts on every request, a collection for every status code, and one-click runs." },
        { title: "Build a custom agent", icon: "🕵️", href: "day3/agents.html", desc: "A read-only Claude Code subagent that reviews your app against CLAUDE.md, then one of your own design." },
        { title: "Claude Code skills", icon: "📇", href: "day4/skills.html", desc: "Write this morning's endpoint recipe as a skill, then let Claude use it for the next endpoint." },
        { title: "CI/CD from zero", icon: "🏭", href: "day4/cicd.html", desc: "Why teams let robots test and ship: CI, Continuous Delivery and Continuous Deployment, a pipeline you can watch, and the words you'll need." },
        { title: "GitHub Actions: CI for your app", icon: "✅", href: "day4/ci.html", desc: "A hello-world workflow first, then Pest tests on every push, and a red pull request that can't be merged." },
        { title: "Deploy to AWS", icon: "☁️", href: "day4/aws.html", desc: "Trainer demo plus a guided lab: EC2, RDS, nightly backups to S3, and deploy on every green push." },
        { title: "Login and roles", icon: "🔐", href: "day4/auth.html", desc: "A login page for the browser: sessions, hashed passwords, and a Policy so each teacher sees only their own section." },
        { title: "Web security (stretch)", icon: "🛡️", href: "day4/security.html", desc: "A grade form, then mass assignment, CSRF, XSS and SQL injection attacks on it. Also your capstone recipe." }
      ] },

    { n: 5, folder: "day5", status: "live", icon: "🎤",
      title: "Capstone",
      goal: "Every table builds the same Student Management Portal in one shared repo: kickoff at 9, build in Must, Should and Stretch tiers, then demo from main at 2:00 (7 minutes plus 3 of questions).",
      blocks: [
        { title: "Capstone brief: Student Management Portal", icon: "🏁", href: "day4/capstone.html", desc: "What to build in three tiers, who may do what, table hints, six seats with one owner per file, the team repo and branches, then the 7+3 demo and how it is scored." }
      ] }
  ]
};
