/* Tiny Git model + visuals (three areas, commit graph, remotes). Pure JS, offline.
   Implements a teaching subset of git with real-looking output. */
(function(){
'use strict';
const esc = C.esc;

function hash(s){ let h=0x811c9dc5; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h; }
function hex7(s){ return ('0000000'+hash(s).toString(16)).slice(-7); }
function hex40(id){ let o=id; while(o.length<40) o += ('00000000'+hash(o).toString(16)).slice(-8); return o.slice(0,40); }
const same = (a,b) => JSON.stringify(sortObj(a))===JSON.stringify(sortObj(b));
function sortObj(o){ const r={}; Object.keys(o||{}).sort().forEach(k=>r[k]=o[k]); return r; }

class World {
  constructor(){ this.commits={}; this.seq=0; this.repos={}; this.config={}; }
  commit(parents, tree, msg, branch, author){
    this.seq++; const id = hex7(this.seq+':'+msg+':'+parents.join(','));
    this.commits[id] = {id, parents, tree:{...tree}, msg, seq:this.seq, branch, author: author || this.config['user.name'] || 'Student'};
    return id;
  }
  ancestors(id){ const s=new Set(); const st=id?[id]:[]; while(st.length){ const c=st.pop(); if(s.has(c)) continue; s.add(c); (this.commits[c].parents||[]).forEach(p=>st.push(p)); } return s; }
  isAnc(a, b){ return !a || this.ancestors(b).has(a); } // a is ancestor of (or equal to) b
  base(a, b){ const A=this.ancestors(a); let best=null; this.ancestors(b).forEach(c => { if(A.has(c) && (!best || this.commits[c].seq > this.commits[best].seq)) best=c; }); return best; }
}

class Repo {
  constructor(world, name, opt={}){
    Object.assign(this, {w:world, name, work:{}, index:{}, branches:{}, head:'main', inited:false, remotes:{}, tracking:{}, upstream:{}, bare:false, path:opt.path||'~/'+name, user:opt.user||'student', host:opt.host||'lab01', listeners:[], events:[]});
    if(opt.url) world.repos[opt.url] = this;
    this.url = opt.url;
  }
  on(f){ this.listeners.push(f); }
  emit(){ this.listeners.forEach(f=>f(this)); this.events=[]; }
  headId(){ return this.branches[this.head]||null; }
  tree(id){ return id ? this.w.commits[id].tree : {}; }
  headTree(){ return this.tree(this.headId()); }
  status(){
    const H=this.headTree(), I=this.index, W=this.work; const files = new Set([...Object.keys(H),...Object.keys(I),...Object.keys(W)]);
    const staged=[], unstaged=[], untracked=[];
    [...files].sort().forEach(f => {
      if(I[f]!==H[f]) staged.push([f, H[f]===undefined?'new file':(I[f]===undefined?'deleted':'modified')]);
      if(!(f in I) && (f in W)) untracked.push(f);
      else if((f in I) && W[f]!==I[f]) unstaged.push([f, W[f]===undefined?'deleted':'modified']);
    });
    return {staged, unstaged, untracked};
  }
  aheadBehind(){
    const up = this.upstream[this.head]; if(!up) return null;
    const t = this.tracking[up]; const h=this.headId();
    const A=this.w.ancestors(h), B=this.w.ancestors(t);
    let ahead=0, behind=0; A.forEach(c=>{ if(!B.has(c)) ahead++; }); B.forEach(c=>{ if(!A.has(c)) behind++; });
    return {up, ahead, behind};
  }
  prompt(){ return '<span class="pr">'+esc(this.user)+'@'+esc(this.host)+':<b>'+esc(this.path)+'</b>'+(this.inited&&!this.bare?' <span style="color:var(--term-yellow)">('+esc(this.head)+')</span>':'')+'$</span>'; }
}

/* ---------- line diff (LCS) ---------- */
function diffLines(a, b){
  const A=(a||'').split('\n'), B=(b||'').split('\n'); if(A.at(-1)==='') A.pop(); if(B.at(-1)==='') B.pop();
  const n=A.length, m=B.length, L=Array.from({length:n+1},()=>new Array(m+1).fill(0));
  for(let i=n-1;i>=0;i--) for(let j=m-1;j>=0;j--) L[i][j] = A[i]===B[j] ? L[i+1][j+1]+1 : Math.max(L[i+1][j], L[i][j+1]);
  const out=[]; let i=0,j=0;
  while(i<n||j<m){ if(i<n&&j<m&&A[i]===B[j]){ out.push([' ',A[i]]); i++; j++; } else if(j<m && (i>=n || L[i][j+1]>=L[i+1][j])){ out.push(['+',B[j]]); j++; } else { out.push(['-',A[i]]); i++; } }
  return {lines:out, n, m};
}

/* ---------- command runner ---------- */
function tok(s){ const out=[]; const re=/"([^"]*)"|'([^']*)'|(>>|>|&&)|([^\s"'>&]+)/g; let m; while((m=re.exec(s))){ out.push(m[1]!==undefined?{v:m[1],q:1}:m[2]!==undefined?{v:m[2],q:1}:m[3]?{v:m[3],op:1}:{v:m[4]}); } return out; }

function run(repo, line){
  const parts=[]; let cur=[]; tok(line.trim()).forEach(t => { if(t.op && t.v==='&&'){ parts.push(cur); cur=[]; } else cur.push(t); }); parts.push(cur);
  let out=[];
  for(const p of parts){ const r = runOne(repo, p); if(r.clear){ repo.emit(); return {clear:true}; } out = out.concat(r.lines||[]); if(r.fail) break; }
  repo.emit();
  return out;
}
const L = (t,c) => ({t, c});

function runOne(repo, toks){
  if(!toks.length) return {lines:[]};
  let redir=null; const args=[];
  for(let i=0;i<toks.length;i++){ if(toks[i].op && (toks[i].v==='>'||toks[i].v==='>>')){ redir={mode:toks[i].v, file:(toks[i+1]||{}).v}; i++; } else args.push(toks[i].v); }
  const [cmd, ...a] = args;
  if(cmd==='echo'){
    const text = a.join(' ')+'\n';
    if(redir){ const f=redir.file; if(redir.mode==='>>' && f in repo.work) repo.work[f]+=text; else repo.work[f]=text; repo.events.push({type:'edit', files:[f]}); return {lines:[]}; }
    return {lines:[L(text.trimEnd())]};
  }
  if(cmd==='cat'){ const ls=[]; for(const f of a){ if(!(f in repo.work)) return {lines:[L('cat: '+f+': No such file or directory','err')], fail:1}; repo.work[f].replace(/\n$/,'').split('\n').forEach(x=>ls.push(L(x))); } return {lines:ls}; }
  if(cmd==='ls'){ const fs=Object.keys(repo.work).sort(); const hidden = a.includes('-a') || a.includes('-la') ? ['.', '..'].concat(repo.inited?['.git']:[]) : []; return {lines:[L(hidden.concat(fs).join('  '))]}; }
  if(cmd==='rm'){ a.filter(x=>!x.startsWith('-')).forEach(f=>{ delete repo.work[f]; }); repo.events.push({type:'edit', files:a}); return {lines:[]}; }
  if(cmd==='clear') return {lines:[], clear:1};
  if(cmd==='mkdir') return {lines:[]};
  if(cmd==='cd'){ if(a[0] && a[0]!=='..' && a[0]!=='~'){ repo.path = repo.path.replace(/\/$/,'')+'/'+a[0]; } else if(a[0]==='..'){ repo.path = repo.path.replace(/\/[^/]+$/,'')||'~'; } else repo.path='~'; return {lines:[]}; }
  if(cmd==='nano' || cmd==='code') return {lines:[L('(In the real terminal this opens the editor. Here we use echo to change files.)','dim')]};
  if(cmd!=='git') return {lines:[L('bash: '+cmd+': command not found','err')], fail:1};
  return git(repo, a);
}

function needRepo(repo){ return repo.inited ? null : {lines:[L('fatal: not a git repository (or any of the parent directories): .git','err')], fail:1}; }

function git(repo, a){
  const w=repo.w; const sub=a[0]; const rest=a.slice(1);
  const flag = f => rest.includes(f);
  switch(sub){
  case undefined: case 'help': return {lines:[L('usage: git [--version] <command> [<args>]'), L('Common: init clone add status diff commit log restore branch switch merge remote push fetch pull')]};
  case '--version': return {lines:[L('git version 2.47.3')]};
  case 'config': {
    const keys = rest.filter(x=>!x.startsWith('--'));
    if(flag('--list') || flag('-l')){ return {lines: Object.entries(w.config).map(([k,v])=>L(k+'='+v))}; }
    if(keys.length===1){ return w.config[keys[0]]!==undefined ? {lines:[L(w.config[keys[0]])]} : {lines:[], fail:1}; }
    if(keys.length>=2){ w.config[keys[0]] = keys.slice(1).join(' '); repo.events.push({type:'config', key:keys[0]}); return {lines:[]}; }
    return {lines:[L('usage: git config [<options>]','err')]};
  }
  case 'init': {
    if(flag('--bare')){ repo.bare=true; repo.inited=true; return {lines:[L('Initialized empty Git repository in '+(repo.url||repo.path)+'/')]}; }
    const p = repo.path.replace('~','/home/'+repo.user);
    if(repo.inited) return {lines:[L('Reinitialized existing Git repository in '+p+'/.git/')]};
    repo.inited=true; repo.head = w.config['init.defaultBranch'] || 'master';
    const lines=[];
    if(!w.config['init.defaultBranch']) ['hint: Using \'master\' as the name for the initial branch. This default branch name','hint: is subject to change. To configure the initial branch name to use in all','hint: of your new repositories, which will suppress this warning, call:','hint:','hint: \tgit config --global init.defaultBranch <name>'].forEach(x=>lines.push(L(x,'hl')));
    lines.push(L('Initialized empty Git repository in '+p+'/.git/'));
    repo.events.push({type:'init'});
    return {lines};
  }
  case 'status': { const e=needRepo(repo); if(e) return e;
    const s=repo.status(); const out=[L('On branch '+repo.head)];
    if(!repo.headId()) out.push(L(''), L('No commits yet'));
    const ab=repo.aheadBehind();
    if(ab){ if(ab.ahead&&ab.behind) out.push(L("Your branch and '"+ab.up+"' have diverged,"), L('and have '+ab.ahead+' and '+ab.behind+' different commits each, respectively.'));
      else if(ab.ahead) out.push(L("Your branch is ahead of '"+ab.up+"' by "+ab.ahead+' commit'+(ab.ahead>1?'s':'')+'.'), L('  (use "git push" to publish your local commits)','dim'));
      else if(ab.behind) out.push(L("Your branch is behind '"+ab.up+"' by "+ab.behind+' commit'+(ab.behind>1?'s':'')+', and can be fast-forwarded.'), L('  (use "git pull" to update your local branch)','dim'));
      else out.push(L("Your branch is up to date with '"+ab.up+"'.")); }
    if(s.staged.length){ out.push(L(''), L('Changes to be committed:'), L('  (use "git restore --staged <file>..." to unstage)','dim')); s.staged.forEach(([f,k])=>out.push(L('\t'+(k+':').padEnd(12)+f,'ok'))); }
    if(s.unstaged.length){ out.push(L(''), L('Changes not staged for commit:'), L('  (use "git add <file>..." to update what will be committed)','dim'), L('  (use "git restore <file>..." to discard changes in working directory)','dim')); s.unstaged.forEach(([f,k])=>out.push(L('\t'+(k+':').padEnd(12)+f,'err'))); }
    if(s.untracked.length){ out.push(L(''), L('Untracked files:'), L('  (use "git add <file>..." to include in what will be committed)','dim')); s.untracked.forEach(f=>out.push(L('\t'+f,'err'))); }
    out.push(L(''));
    if(!s.staged.length && !s.unstaged.length && !s.untracked.length) out.push(L(repo.headId()?'nothing to commit, working tree clean':'nothing to commit (create/copy files and use "git add" to track)'));
    else if(!s.staged.length) out.push(L(s.unstaged.length?'no changes added to commit (use "git add" and/or "git commit -a")':'nothing added to commit but untracked files present (use "git add" to track)'));
    return {lines:out}; }
  case 'add': { const e=needRepo(repo); if(e) return e;
    let files = rest.filter(x=>!x.startsWith('-'));
    if(!files.length && !flag('-A')) return {lines:[L('Nothing specified, nothing added.'), L("hint: Maybe you wanted to say 'git add .'?",'hl')]};
    if(files.includes('.') || flag('-A')) files = [...new Set([...Object.keys(repo.work), ...Object.keys(repo.index)])];
    const moved=[];
    for(const f of files){
      if(f in repo.work){ if(repo.index[f]!==repo.work[f]) moved.push(f); repo.index[f]=repo.work[f]; }
      else if(f in repo.index){ delete repo.index[f]; moved.push(f); }
      else return {lines:[L("fatal: pathspec '"+f+"' did not match any files",'err')], fail:1};
    }
    repo.events.push({type:'add', files:moved});
    return {lines:[]}; }
  case 'commit': { const e=needRepo(repo); if(e) return e;
    const mi = rest.indexOf('-m'); const am = rest.indexOf('-am');
    if(am>=0){ Object.keys(repo.index).forEach(f=>{ if(f in repo.work) repo.index[f]=repo.work[f]; else delete repo.index[f]; }); }
    const msg = mi>=0 ? rest[mi+1] : (am>=0 ? rest[am+1] : null);
    if(!w.config['user.name'] || !w.config['user.email']) return {lines:['Author identity unknown','','*** Please tell me who you are.','','Run','','  git config --global user.email "you@example.com"','  git config --global user.name "Your Name"','',"fatal: unable to auto-detect email address (got 'student@lab01.(none)')"].map(x=>L(x,'err')), fail:1};
    if(!msg) return {lines:[L('(Without -m, git opens your editor (nano) to write the message. Use -m "message" here.)','hl')], fail:1};
    const H=repo.headTree();
    if(same(H, repo.index)){ const s=repo.status(); return {lines:[L('On branch '+repo.head), L(s.unstaged.length||s.untracked.length ? 'no changes added to commit (use "git add" and/or "git commit -a")' : 'nothing to commit, working tree clean')], fail:1}; }
    const parent = repo.headId();
    const id = w.commit(parent?[parent]:[], repo.index, msg, repo.head);
    repo.branches[repo.head]=id;
    let changed=0, ins=0, del=0; const modes=[];
    new Set([...Object.keys(H),...Object.keys(repo.index)]).forEach(f => { if(H[f]!==repo.index[f]){ changed++; const d=diffLines(H[f],repo.index[f]); d.lines.forEach(([k])=>{ if(k==='+')ins++; if(k==='-')del++; }); if(H[f]===undefined) modes.push(' create mode 100644 '+f); if(repo.index[f]===undefined) modes.push(' delete mode 100644 '+f); } });
    repo.events.push({type:'commit', id});
    return {lines:[L('['+repo.head+(parent?'':' (root-commit)')+' '+id+'] '+msg), L(' '+changed+' file'+(changed>1?'s':'')+' changed'+(ins?', '+ins+' insertion'+(ins>1?'s':'')+'(+)':'')+(del?', '+del+' deletion'+(del>1?'s':'')+'(-)':''))].concat(modes.map(m=>L(m)))}; }
  case 'log': { const e=needRepo(repo); if(e) return e;
    const starts = flag('--all') ? Object.values(repo.branches).concat(Object.values(repo.tracking)) : [repo.headId()];
    if(!repo.headId()) return {lines:[L("fatal: your current branch '"+repo.head+"' does not have any commits yet",'err')], fail:1};
    const set=new Set(); starts.filter(Boolean).forEach(s=>w.ancestors(s).forEach(c=>set.add(c)));
    const list=[...set].map(id=>w.commits[id]).sort((x,y)=>y.seq-x.seq);
    const n = (rest.find(x=>/^-\d+$/.test(x))||'').slice(1);
    const lim = n ? list.slice(0,+n) : list;
    const out=[];
    lim.forEach(c => {
      const refs=[]; Object.entries(repo.branches).forEach(([b,id])=>{ if(id===c.id) refs.push(b===repo.head?'HEAD -> '+b:b); }); Object.entries(repo.tracking).forEach(([b,id])=>{ if(id===c.id) refs.push(b); });
      refs.sort((x,y)=> (y.startsWith('HEAD')?1:0)-(x.startsWith('HEAD')?1:0));
      const r = refs.length? ' ('+refs.join(', ')+')' : '';
      if(flag('--oneline')) out.push({html:'<span class="hl">'+c.id+'</span><span class="blue">'+esc(r)+'</span> '+esc(c.msg)});
      else { out.push({html:'<span class="hl">commit '+hex40(c.id)+'</span><span class="blue">'+esc(r)+'</span>'}); if(c.parents.length>1) out.push(L('Merge: '+c.parents.join(' '))); out.push(L('Author: '+c.author+' <'+(w.config['user.email']||'student@example.com')+'>')); out.push(L('Date:   Mon Nov 23 09:'+String(10+c.seq).padStart(2,'0')+':00 2026 +0800')); out.push(L('')); out.push(L('    '+c.msg)); out.push(L('')); }
    });
    return {lines:out}; }
  case 'diff': { const e=needRepo(repo); if(e) return e;
    const staged = flag('--staged') || flag('--cached'); const only = rest.filter(x=>!x.startsWith('-'));
    const A = staged ? repo.headTree() : repo.index, B = staged ? repo.index : repo.work;
    const out=[];
    [...new Set([...Object.keys(A),...Object.keys(B)])].sort().forEach(f => {
      if(only.length && !only.includes(f)) return;
      if(!staged && !(f in repo.index)) return; // untracked files are not shown by git diff
      if(A[f]===B[f]) return;
      const d=diffLines(A[f],B[f]);
      out.push(L('diff --git a/'+f+' b/'+f,'b')); if(A[f]===undefined) out.push(L('new file mode 100644')); out.push(L('--- '+(A[f]===undefined?'/dev/null':'a/'+f))); out.push(L('+++ '+(B[f]===undefined?'/dev/null':'b/'+f)));
      out.push(L('@@ -1,'+d.n+' +1,'+d.m+' @@','blue'));
      d.lines.forEach(([k,t])=>out.push(L(k+t, k==='+'?'ok':k==='-'?'err':'')));
    });
    repo.events.push({type:'diff', staged});
    return {lines:out}; }
  case 'restore': { const e=needRepo(repo); if(e) return e;
    const files=rest.filter(x=>!x.startsWith('-')); const H=repo.headTree();
    for(const f of files){
      if(flag('--staged')){ if(f in H) repo.index[f]=H[f]; else delete repo.index[f]; }
      else { if(!(f in repo.index)) return {lines:[L("error: pathspec '"+f+"' did not match any file(s) known to git",'err')], fail:1}; repo.work[f]=repo.index[f]; }
    }
    repo.events.push({type: flag('--staged')?'unstage':'restore', files});
    return {lines:[]}; }
  case 'branch': { const e=needRepo(repo); if(e) return e;
    const names=rest.filter(x=>!x.startsWith('-'));
    if(flag('-d')||flag('-D')){ const b=names[0]; if(b===repo.head) return {lines:[L("error: cannot delete branch '"+b+"' used by worktree",'err')], fail:1}; if(!(b in repo.branches)) return {lines:[L("error: branch '"+b+"' not found",'err')], fail:1};
      if(flag('-d') && !w.isAnc(repo.branches[b], repo.headId())) return {lines:[L("error: the branch '"+b+"' is not fully merged.",'err'), L("hint: If you are sure you want to delete it, run 'git branch -D "+b+"'",'hl')], fail:1};
      const id=repo.branches[b]; delete repo.branches[b]; return {lines:[L('Deleted branch '+b+' (was '+id+').')]}; }
    if(!names.length || flag('-a') || flag('-v')){ const out = Object.keys(repo.branches).sort().map(b => b===repo.head ? {html:'* <span class="ok">'+esc(b)+'</span>'} : L('  '+b)); if(flag('-a')) Object.keys(repo.tracking).forEach(t=>out.push({html:'  <span class="err">remotes/'+esc(t)+'</span>'})); return {lines:out}; }
    if(!repo.headId()) return {lines:[L("fatal: not a valid object name: '"+repo.head+"'",'err')], fail:1};
    if(names[0] in repo.branches) return {lines:[L("fatal: a branch named '"+names[0]+"' already exists",'err')], fail:1};
    repo.branches[names[0]] = repo.headId(); repo.events.push({type:'branch', name:names[0]}); return {lines:[]}; }
  case 'switch': case 'checkout': { const e=needRepo(repo); if(e) return e;
    const create = flag('-c') || flag('-b'); const name = rest.filter(x=>!x.startsWith('-'))[0];
    if(!name) return {lines:[L('fatal: missing branch name','err')], fail:1};
    if(create){ if(name in repo.branches) return {lines:[L("fatal: a branch named '"+name+"' already exists",'err')], fail:1}; if(!repo.headId()){ repo.head=name; return {lines:[L("Switched to a new branch '"+name+"'")]}; } repo.branches[name]=repo.headId(); repo.head=name; repo.events.push({type:'switch'}); return {lines:[L("Switched to a new branch '"+name+"'")]}; }
    if(!(name in repo.branches)){
      const tr = 'origin/'+name; if(repo.tracking[tr]){ repo.branches[name]=repo.tracking[tr]; repo.upstream[name]=tr; }
      else return {lines:[L("fatal: invalid reference: "+name,'err')], fail:1};
    }
    if(name===repo.head) return {lines:[L("Already on '"+name+"'")]};
    const r = checkoutTree(repo, repo.branches[name]); if(r) return r;
    repo.head=name; repo.events.push({type:'switch'});
    return {lines:[L("Switched to branch '"+name+"'")]}; }
  case 'merge': { const e=needRepo(repo); if(e) return e;
    const name=rest.filter(x=>!x.startsWith('-'))[0]; const target = repo.branches[name] || repo.tracking[name];
    if(!target) return {lines:[L('merge: '+name+' - not something we can merge','err')], fail:1};
    return mergeInto(repo, target, name); }
  case 'remote': { const e=needRepo(repo); if(e) return e;
    if(rest[0]==='add'){ repo.remotes[rest[1]]=rest[2]; return {lines:[]}; }
    if(rest[0]==='-v' || !rest.length){ return {lines: Object.entries(repo.remotes).flatMap(([n,u]) => rest[0]==='-v'?[L(n+'\t'+u+' (fetch)'),L(n+'\t'+u+' (push)')]:[L(n)])}; }
    return {lines:[]}; }
  case 'push': { const e=needRepo(repo); if(e) return e;
    const pos=rest.filter(x=>!x.startsWith('-')); const rn=pos[0]||'origin'; const br=pos[1]||repo.head; const url=repo.remotes[rn];
    if(!url) return {lines:[L("fatal: '"+rn+"' does not appear to be a git repository",'err'), L('fatal: Could not read from remote repository.','err')], fail:1};
    if(!pos.length && !repo.upstream[br]) return {lines:[L('fatal: The current branch '+br+' has no upstream branch.','err'), L('To push the current branch and set the remote as upstream, use','hl'), L(''), L('    git push --set-upstream origin '+br,'hl')], fail:1};
    const R=w.repos[url]; const local=repo.branches[br]; if(!local) return {lines:[L('error: src refspec '+br+' does not match any','err')], fail:1};
    const remoteId=R.branches[br]; const out=[L('To '+url)];
    if(remoteId && !w.isAnc(remoteId, local)){
      repo.events.push({type:'rejected'});
      return {lines: out.concat([L(' ! [rejected]        '+br+' -> '+br+' (fetch first)','err'), L("error: failed to push some refs to '"+url+"'",'err'), L('hint: Updates were rejected because the remote contains work that you do not','hl'), L('hint: have locally. Integrate the remote changes (e.g. \'git pull ...\')','hl'), L('hint: before pushing again.','hl')]), fail:1};
    }
    if(remoteId===local){ return {lines:[L('Everything up-to-date')]}; }
    R.branches[br]=local; R.inited=true; repo.tracking[rn+'/'+br]=local;
    out.push(L(remoteId ? '   '+remoteId+'..'+local+'  '+br+' -> '+br : ' * [new branch]      '+br+' -> '+br));
    if(flag('-u') || flag('--set-upstream')){ repo.upstream[br]=rn+'/'+br; out.push(L("branch '"+br+"' set up to track '"+rn+'/'+br+"'.")); }
    repo.events.push({type:'push', to:R}); R.events.push({type:'received'}); R.emit();
    return {lines:out}; }
  case 'fetch': { const e=needRepo(repo); if(e) return e; return fetch(repo); }
  case 'pull': { const e=needRepo(repo); if(e) return e;
    const f = fetch(repo); const up = repo.upstream[repo.head] || 'origin/'+repo.head; const t=repo.tracking[up];
    if(!t) return {lines:f.lines.concat([L('There is no tracking information for the current branch.','err')]), fail:1};
    const m = mergeInto(repo, t, up, true);
    return {lines:f.lines.concat(m.lines), fail:m.fail}; }
  case 'clone': {
    const url=rest[0]; const R=w.repos[url];
    if(!R) return {lines:[L("fatal: repository '"+url+"' not found",'err')], fail:1};
    const dir = rest[1] || url.split('/').pop().replace(/\.git$/,'');
    repo.inited=true; repo.remotes.origin=url;
    Object.entries(R.branches).forEach(([b,id])=>repo.tracking['origin/'+b]=id);
    const hb = R.branches.main ? 'main' : Object.keys(R.branches)[0];
    repo.head=hb; repo.branches[hb]=R.branches[hb]; repo.upstream[hb]='origin/'+hb;
    repo.index={...repo.tree(R.branches[hb])}; repo.work={...repo.index};
    repo.events.push({type:'clone'});
    return {lines:[L("Cloning into '"+dir+"'..."), L('remote: Enumerating objects: '+(w.ancestors(R.branches[hb]).size*3)+', done.'), L('Receiving objects: 100%, done.')]}; }
  default: return {lines:[L("git: '"+sub+"' is not a git command. See 'git --help'.",'err')], fail:1};
  }
}

function fetch(repo){
  const url=repo.remotes.origin; if(!url) return {lines:[L("fatal: 'origin' does not appear to be a git repository",'err')], fail:1};
  const R=repo.w.repos[url]; const out=[];
  Object.entries(R.branches).forEach(([b,id]) => { const k='origin/'+b; const old=repo.tracking[k]; if(old!==id){ out.push(L(old? '   '+old+'..'+id+'  '+b+'       -> '+k : ' * [new branch]      '+b+'       -> '+k)); repo.tracking[k]=id; } });
  if(out.length) out.unshift(L('From '+url));
  repo.events.push({type:'fetch', from:R});
  return {lines:out};
}

function dirtyFiles(repo){ const s=repo.status(); return new Set([...s.staged.map(x=>x[0]), ...s.unstaged.map(x=>x[0])]); }
function checkoutTree(repo, id){
  const H=repo.headTree(), T=repo.tree(id); const dirty=dirtyFiles(repo); const bad=[...dirty].filter(f=>H[f]!==T[f]);
  if(bad.length) return {lines:[L('error: Your local changes to the following files would be overwritten by checkout:','err')].concat(bad.map(f=>L('\t'+f,'err'))).concat([L('Please commit your changes or stash them before you switch branches.','err'), L('Aborting','err')]), fail:1};
  const nw={...T}, ni={...T};
  dirty.forEach(f => { if(f in repo.work) nw[f]=repo.work[f]; else delete nw[f]; if(f in repo.index) ni[f]=repo.index[f]; else delete ni[f]; });
  repo.status().untracked.forEach(f => nw[f]=repo.work[f]);
  repo.work=nw; repo.index=ni; return null;
}
function mergeInto(repo, target, name, isPull){
  const w=repo.w; const h=repo.headId();
  if(w.isAnc(target, h)) return {lines:[L('Already up to date.')]};
  if(!h || w.isAnc(h, target)){
    const r=checkoutTree(repo, target); if(r) return r;
    repo.branches[repo.head]=target; repo.events.push({type:'merge', ff:true});
    return {lines:[L('Updating '+(h||'0000000')+'..'+target), L('Fast-forward')]};
  }
  const b=w.base(h,target); const B=repo.tree(b), O=repo.tree(h), T=repo.tree(target); const res={}; const conflicts=[];
  new Set([...Object.keys(B),...Object.keys(O),...Object.keys(T)]).forEach(f => {
    if(O[f]===T[f]) { if(O[f]!==undefined) res[f]=O[f]; }
    else if(O[f]===B[f]) { if(T[f]!==undefined) res[f]=T[f]; }
    else if(T[f]===B[f]) { if(O[f]!==undefined) res[f]=O[f]; }
    else conflicts.push(f);
  });
  if(dirtyFiles(repo).size) return {lines:[L('error: Your local changes would be overwritten by merge. Commit them first.','err')], fail:1};
  if(conflicts.length){ return {lines: conflicts.map(f=>L('CONFLICT (content): Merge conflict in '+f,'err')).concat([L('Automatic merge failed; fix conflicts and then commit the result.','err'), L('(This practice sim stops here. Merge conflicts are a Day 4 topic, with real team projects.)','hl')]), fail:1}; }
  const msg = isPull ? "Merge branch '"+repo.head+"' of "+(repo.remotes.origin||'origin') : "Merge branch '"+name+"'";
  const id = w.commit([h,target], res, msg, repo.head);
  repo.branches[repo.head]=id; repo.index={...res}; repo.work={...res};
  repo.events.push({type:'merge', id});
  return {lines:[L("Merge made by the 'ort' strategy.")]};
}

window.GitSim = {World, Repo, run, diffLines};

/* ======================= visuals ======================= */
function fly(fromRect, toEl, html, cls){
  if(!fromRect || !toEl) return;
  const to = toEl.getBoundingClientRect();
  const d = document.createElement('div'); d.className='flyer '+(cls||''); d.innerHTML=html;
  Object.assign(d.style, {left:fromRect.left+'px', top:fromRect.top+'px', width:fromRect.width+'px'});
  document.body.appendChild(d);
  requestAnimationFrame(()=>requestAnimationFrame(()=>{ Object.assign(d.style, {left:to.left+'px', top:to.top+'px', width:to.width+'px', opacity:.2}); }));
  setTimeout(()=>d.remove(), 800);
}

class AreasVis {
  constructor(el, repo){
    this.el=el; this.repo=repo;
    el.innerHTML = '<div class="areas"><div class="area wd"><h4>① Working directory <small>your folder</small></h4><div class="list"></div></div><div class="area ix"><h4>② Staging area <small>next snapshot</small></h4><div class="list"></div></div><div class="area rp"><h4>③ Repository <small>history in .git</small></h4><div class="list"></div></div></div>'+
      '<div style="font-size:.66rem;color:var(--muted);margin-top:.4rem">Badges: <span class="pill" style="background:var(--bad);color:#fff">U</span> untracked (Git has never seen it) · <span class="pill" style="background:var(--warn)">M</span> modified, not staged · <span class="pill" style="background:var(--ok)">A/M</span> staged for the next commit · grey = same as last commit</div>';
    this.wd=el.querySelector('.wd .list'); this.ix=el.querySelector('.ix .list'); this.rp=el.querySelector('.rp .list');
    repo.on(()=>this.render()); this.render();
  }
  render(){
    const r=this.repo, evs=[...r.events];
    const oldRects={}; this.el.querySelectorAll('[data-k]').forEach(n=>oldRects[n.dataset.k]=n.getBoundingClientRect());
    const ixRect = this.ix.getBoundingClientRect();
    const H=r.headTree(), I=r.index, W=r.work;
    const prev = v => esc((v||'').split('\n')[0].slice(0,26));
    if(!r.inited){ this.ix.innerHTML='<div style="color:var(--muted);font-size:.7rem">Not a Git repository yet.<br>Run <code>git init</code>.</div>'; this.rp.innerHTML='<div style="color:var(--muted);font-size:.7rem">No <code>.git</code> folder.</div>'; }
    this.wd.innerHTML = Object.keys(W).sort().map(f => { let st='clean', b='✓'; if(r.inited){ if(!(f in I)){st='untracked';b='U';} else if(W[f]!==I[f]){st='modified';b='M';} } else { st='untracked'; b='?'; } return '<div class="fchip '+st+'" data-k="wd:'+esc(f)+'">📄 '+esc(f)+' <span class="ct">'+prev(W[f])+'</span><span class="st">'+b+'</span></div>'; }).join('') || '<div style="color:var(--muted);font-size:.7rem">(empty folder)</div>';
    if(r.inited){
      const fs=[...new Set([...Object.keys(I),...Object.keys(H)])].sort();
      this.ix.innerHTML = fs.map(f => { let st='clean', b='='; if(!(f in I)){ st='staged'; b='D'; } else if(I[f]!==H[f]){ st='staged'; b= f in H?'M':'A'; } return '<div class="fchip '+st+'" data-k="ix:'+esc(f)+'">📄 '+esc(f)+' <span class="ct">'+(f in I?prev(I[f]):'(deleted)')+'</span><span class="st">'+b+'</span></div>'; }).join('') || '<div style="color:var(--muted);font-size:.7rem">(empty). <code>git add</code> puts files here</div>';
      const ids=new Set(); Object.values(r.branches).forEach(id=>r.w.ancestors(id).forEach(c=>ids.add(c)));
      const list=[...ids].map(id=>r.w.commits[id]).sort((a,b)=>b.seq-a.seq);
      this.rp.innerHTML = list.slice(0,6).map(c => { const refs=Object.entries(r.branches).filter(([b,id])=>id===c.id).map(([b])=>(b===r.head?'<span class="head">HEAD → '+esc(b)+'</span>':'<span>'+esc(b)+'</span>')).join(''); return '<div class="ccard" data-k="c:'+c.id+'"><span class="h">'+c.id+'</span> '+esc(c.msg)+' <span class="refs">'+refs+'</span><div class="files">📸 '+Object.keys(c.tree).sort().map(esc).join(' · ')+'</div></div>'; }).join('') + (list.length>6?'<div style="color:var(--muted);font-size:.65rem">… '+(list.length-6)+' older</div>':'') || '<div style="color:var(--muted);font-size:.7rem">No commits yet.</div>';
    }
    // animations
    evs.forEach(e => {
      if(e.type==='add') e.files.forEach(f => { const to=this.el.querySelector('[data-k="ix:'+CSS.escape(f)+'"]'); if(to) fly(oldRects['wd:'+f], to, '<div class="fchip staged">📄 '+esc(f)+'</div>'); });
      if(e.type==='commit'){ const to=this.el.querySelector('[data-k="c:'+e.id+'"]'); if(to){ fly(ixRect, to, '<div class="ccard" style="height:100%">📸 snapshot</div>'); this.el.querySelector('.rp').classList.remove('pulse'); void this.el.offsetWidth; this.el.querySelector('.rp').classList.add('pulse'); } }
      if(e.type==='unstage') e.files.forEach(f => { const to=this.el.querySelector('[data-k="wd:'+CSS.escape(f)+'"]'); if(to) fly(oldRects['ix:'+f], to, '<div class="fchip modified">📄 '+esc(f)+'</div>'); });
      if(e.type==='restore') e.files.forEach(f => { const to=this.el.querySelector('[data-k="wd:'+CSS.escape(f)+'"]'); if(to) fly(oldRects['ix:'+f], to, '<div class="fchip">📄 '+esc(f)+'</div>'); });
      if(e.type==='edit') e.files.forEach(f => { const n=this.el.querySelector('[data-k="wd:'+CSS.escape(f)+'"]'); if(n){ n.style.animation='pop .5s'; } });
    });
  }
}
window.AreasVis = AreasVis;

class GraphVis {
  constructor(el, repo, opt={}){
    this.el=el; this.repo=repo; this.opt=opt; this.nodes={}; this.refs={};
    el.innerHTML = '<svg class="graph" preserveAspectRatio="xMinYMin meet"><g class="edges"></g><g class="cn"></g><g class="rf"></g></svg>';
    this.svg=el.querySelector('svg'); this.ge=el.querySelector('.edges'); this.gn=el.querySelector('.cn'); this.gr=el.querySelector('.rf');
    this.lanes={}; repo.on(()=>this.render()); this.render();
  }
  render(){
    const r=this.repo, w=r.w, NS='http://www.w3.org/2000/svg';
    const roots = Object.values(r.branches).concat(this.opt.noTracking?[]:Object.values(r.tracking)).filter(Boolean);
    const ids=new Set(); roots.forEach(id=>w.ancestors(id).forEach(c=>ids.add(c)));
    const list=[...ids].map(id=>w.commits[id]).sort((a,b)=>a.seq-b.seq);
    const dx=this.opt.dx||92, dy=this.opt.dy||78, x0=40, y0=this.opt.y0||62;
    // lane per branch name, but a commit that would sit on a lane already taken by an unrelated tip gets a new lane
    const byBranch={main:0}, occupied={}, laneOf={}; let nextLane=1;
    list.forEach(c => {
      if(!(c.branch in byBranch)) byBranch[c.branch]=nextLane++;
      let l = byBranch[c.branch];
      if(occupied[l] && !c.parents.includes(occupied[l])){ l = nextLane++; }
      laneOf[c.id]=l; occupied[l]=c.id;
    });
    const laneOrder=[...new Set(Object.values(laneOf))].sort((a,b)=>a-b); const laneY = l => y0 + laneOrder.indexOf(l)*dy;
    const pos={}; list.forEach((c,i)=>pos[c.id]={x:x0+i*dx, y:laneY(laneOf[c.id])});
    const mlen = Math.max(8, Math.floor(dx/6.4));
    const W = Math.max(this.opt.minW||300, x0+list.length*dx+30), Hh = y0 + Math.max(1,laneOrder.length)*dy + (this.opt.extraH||10);
    this.svg.setAttribute('viewBox','0 0 '+W+' '+Hh); this.svg.style.height = (this.opt.scaleH? Math.min(this.opt.scaleH, Hh) : Hh)+'px';
    if(this.opt.fit) { this.svg.style.height='auto'; }
    // edges
    this.ge.innerHTML = list.map(c => c.parents.filter(p=>pos[p]).map(p => { const a=pos[p], b=pos[c.id]; if(a.y===b.y) return '<path class="edge" d="M'+a.x+' '+a.y+' L'+b.x+' '+b.y+'"/>'; const mx=(a.x+b.x)/2; return '<path class="edge" d="M'+a.x+' '+a.y+' C'+mx+' '+a.y+' '+mx+' '+b.y+' '+b.x+' '+b.y+'"/>'; }).join('')).join('');
    // nodes
    const seen=new Set();
    list.forEach(c => { seen.add(c.id); let g=this.nodes[c.id]; const p=pos[c.id];
      if(!g){ g=document.createElementNS(NS,'g'); g.setAttribute('class','cnode new'); g.innerHTML='<circle r="11"></circle><text y="30" text-anchor="middle">'+c.id+'</text><text class="msg" y="44" text-anchor="middle">'+esc(c.msg.length>mlen?c.msg.slice(0,mlen-1)+'…':c.msg)+'</text>'; this.gn.appendChild(g); this.nodes[c.id]=g; setTimeout(()=>g.classList.remove('new'),700); }
      g.style.transform='translate('+p.x+'px,'+p.y+'px)'; });
    Object.keys(this.nodes).forEach(id=>{ if(!seen.has(id)){ this.nodes[id].remove(); delete this.nodes[id]; } });
    // refs (stacked above node)
    const stack={}; const want=[];
    const pushRef=(key, label, cls, id, below) => { if(!pos[id]) return; const k=id+(below?'b':'a'); stack[k]=(stack[k]||0)+1; const n=stack[k]; const p=pos[id]; want.push({key,label,cls,x:p.x,y: below ? p.y+44+n*20 : p.y-20-(n-1)*22}); };
    Object.entries(r.branches).forEach(([b,id]) => pushRef('b:'+b, b, '', id));
    if(r.inited && !r.bare) { const hid=r.headId(); if(hid) pushRef('HEAD','HEAD','head',hid); }
    if(!this.opt.noTracking) Object.entries(r.tracking).forEach(([b,id]) => pushRef('t:'+b, b, 'remote', id, true));
    const keep=new Set();
    want.forEach(o => { keep.add(o.key); let g=this.refs[o.key];
      if(!g){ g=document.createElementNS(NS,'g'); g.setAttribute('class','ref '+o.cls); const wpx = o.label.length*7.2+16; g.innerHTML='<rect x="'+(-wpx/2)+'" y="-10" width="'+wpx+'" height="20" rx="9"></rect><text text-anchor="middle" y="4">'+esc(o.label)+'</text>'; this.gr.appendChild(g); this.refs[o.key]=g; g.style.transform='translate('+o.x+'px,'+(o.y-30)+'px)'; g.getBoundingClientRect(); }
      g.style.transform='translate('+o.x+'px,'+o.y+'px)'; });
    Object.keys(this.refs).forEach(k=>{ if(!keep.has(k)){ this.refs[k].remove(); delete this.refs[k]; } });
    if(!list.length){ this.ge.innerHTML='<text x="20" y="40" style="fill:var(--muted);font:12px var(--sans)">'+(r.inited?'No commits yet':'(no repository)')+'</text>'; }
  }
}
window.GraphVis = GraphVis;
})();
