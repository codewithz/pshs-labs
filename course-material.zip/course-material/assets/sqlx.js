/* SQL practice engine: fill-in-the-blank exercises checked by running real SQL
   in the browser (sql.js = SQLite compiled to WebAssembly, bundled in assets/vendor).
   Students type MariaDB syntax; translate() maps the few bits SQLite reads differently.
   Needs: course.js (window.C), vendor/sql-wasm.js, vendor/sql-wasm-b64.js, a window.SCHOOL dataset. */
(function(){
'use strict';
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const store = (window.C && window.C.store) || { get:(k,d)=>d, set(){} };

/* ---------------- engine ---------------- */
let SQLp = null;
function getSQL(){
  if(!SQLp){
    const b = atob(window.SQL_WASM_B64); const bin = new Uint8Array(b.length);
    for(let i=0;i<b.length;i++) bin[i] = b.charCodeAt(i);
    SQLp = initSqlJs({ wasmBinary: bin });
  }
  return SQLp;
}

/* split a script into statements on ; outside quotes and comments */
function split(sql){
  const out=[]; let cur='', q=null, i=0;
  while(i < sql.length){
    const c = sql[i], n = sql[i+1];
    if(q){ cur+=c; if(c===q){ if(n===q){ cur+=n; i++; } else q=null; } else if(c==='\\' && q!=='`'){ cur+=n||''; i++; } i++; continue; }
    if(c==='-' && n==='-'){ while(i<sql.length && sql[i]!=='\n') i++; continue; }
    if(c==='#'){ while(i<sql.length && sql[i]!=='\n') i++; continue; }
    if(c==='/' && n==='*'){ i+=2; while(i<sql.length && !(sql[i]==='*' && sql[i+1]==='/')) i++; i+=2; continue; }
    if(c==="'"||c==='"'||c==='`'){ q=c; cur+=c; i++; continue; }
    if(c===';'){ if(cur.trim()) out.push(cur.trim()); cur=''; i++; continue; }
    cur+=c; i++;
  }
  if(cur.trim()) out.push(cur.trim());
  return out;
}

class SqlErr extends Error {}
/* MariaDB statement -> SQLite statement */
function translate(st){
  let s = st.trim();
  if(/^(USE\s|CREATE\s+(DATABASE|SCHEMA)\b|DROP\s+(DATABASE|SCHEMA)\b|SET\s+(NAMES|FOREIGN_KEY_CHECKS|SQL_MODE)\b)/i.test(s)) return null;
  if(/^SHOW\s+TABLES\b/i.test(s)) return "SELECT name AS Tables_in_school FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name";
  let m = s.match(/^(?:DESCRIBE|DESC|SHOW\s+COLUMNS\s+FROM)\s+`?(\w+)`?$/i);
  if(m) return "SELECT name AS Field, type AS Type, CASE WHEN \"notnull\"=1 OR pk>0 THEN 'NO' ELSE 'YES' END AS \"Null\", CASE WHEN pk>0 THEN 'PRI' ELSE '' END AS \"Key\" FROM pragma_table_info('"+m[1]+"')";
  s = s.replace(/^START\s+TRANSACTION\b/i, 'BEGIN');
  if(/^CREATE\s+TABLE\b/i.test(s)){
    if(/\bAUTOINCREMENT\b/i.test(s)) throw new SqlErr('MariaDB spells it AUTO_INCREMENT, with an underscore. (AUTOINCREMENT is the SQLite spelling.)');
    s = s.replace(/\bINT(?:EGER)?(\s+UNSIGNED)?\s+(NOT\s+NULL\s+)?AUTO_INCREMENT\s+PRIMARY\s+KEY\b/ig, 'INTEGER PRIMARY KEY AUTOINCREMENT')
         .replace(/\bINT(?:EGER)?(\s+UNSIGNED)?\s+(NOT\s+NULL\s+)?PRIMARY\s+KEY\s+AUTO_INCREMENT\b/ig, 'INTEGER PRIMARY KEY AUTOINCREMENT');
    if(/\bAUTO_INCREMENT\b/i.test(s)) throw new SqlErr('Incorrect table definition: AUTO_INCREMENT only works on an INT column that is also the PRIMARY KEY. (MariaDB: ERROR 1075)');
    s = s.replace(/\b((?:VAR)?CHAR\s*\(\s*\d+\s*\))/ig, '$1 COLLATE NOCASE')
         .replace(/\)\s*(ENGINE|DEFAULT\s+CHARSET|CHARSET|COLLATE)\b[^)]*$/i, ')');
  }
  return s;
}

/* run a whole script; stops at the first error, like the mariadb client */
function run(db, sql){
  const stmts = split(sql); const r = { sets:[], changes:0, wrote:false, count:stmts.length, error:null };
  for(const st of stmts){
    let t;
    try{ t = translate(st); }catch(e){ r.error = e.message; r.failed = st; return r; }
    if(t===null) continue;
    try{
      const res = db.exec(t);
      if(/^\s*(INSERT|UPDATE|DELETE|REPLACE)\b/i.test(t)){ r.changes += db.getRowsModified(); r.wrote = true; }
      if(res.length) r.sets.push(res[res.length-1]);
      else if(/^\s*(SELECT|WITH|PRAGMA)\b/i.test(t)) r.sets.push({ columns: colsOf(db, t), values: [] });
    }catch(e){ r.error = e.message; r.failed = st; return r; }
  }
  r.last = r.sets[r.sets.length-1] || null;
  return r;
}
function colsOf(db, sql){ try{ const s=db.prepare(sql); const c=s.getColumnNames(); s.free(); return c; }catch(e){ return []; } }

const cache = {};
async function freshDB(setup, extra){
  const SQL = await getSQL(); const key = setup + '|' + (extra||'');
  if(!cache[key]){
    const db = new SQL.Database(); db.exec('PRAGMA foreign_keys=ON');
    const S = window.SCHOOL;
    const tabs = setup==='full' ? S.order : (setup && setup!=='none' ? setup.split(',') : []);
    tabs.forEach(t => db.exec(translate(S.schema[t])));
    if(setup==='full') run(db, S.data);
    if(extra){ const r = run(db, extra); if(r.error) console.error('setup', r.error); }
    cache[key] = db.export(); db.close();
  }
  const d = new SQL.Database(cache[key]); d.exec('PRAGMA foreign_keys=ON'); return d;
}

/* friendly error text: [plain explanation, what MariaDB would print] */
function friendly(msg){
  let m;
  if((m = msg.match(/near "([^"]*)": syntax error/))) return ['The database could not read your SQL near <code>'+esc(m[1])+'</code>. Look for a misspelt keyword, a missing comma, or a keyword in the wrong place.', 'ERROR 1064 (42000): You have an error in your SQL syntax'];
  if(/incomplete input/.test(msg)) return ['Your SQL stops too early. Check for a missing <code>)</code>, an unclosed <code>\'</code> quote, or a blank you left empty.', 'ERROR 1064 (42000): You have an error in your SQL syntax'];
  if((m = msg.match(/no such table: (\S+)/))) return ['There is no table called <code>'+esc(m[1])+'</code>. Check the spelling. <code>SHOW TABLES;</code> lists the real names.', "ERROR 1146 (42S02): Table 'school."+esc(m[1])+"' doesn't exist"];
  if((m = msg.match(/no such column: (\S+)/))) return ['There is no column called <code>'+esc(m[1])+'</code> here. Check the spelling, and check that the column belongs to a table in your FROM or JOIN.', "ERROR 1054 (42S22): Unknown column '"+esc(m[1])+"'"];
  if((m = msg.match(/ambiguous column name: (\S+)/))) return ['Two of your tables both have a column called <code>'+esc(m[1])+'</code>. Put the table name or alias in front, like <code>s.'+esc(m[1])+'</code>.', "ERROR 1052 (23000): Column '"+esc(m[1])+"' is ambiguous"];
  if(/FOREIGN KEY constraint failed/.test(msg)) return ['Foreign key check failed. Either the row points to an id that does not exist, or other rows still point to the row you are deleting.', 'ERROR 1452 / 1451 (23000): Cannot add or update a child row / Cannot delete or update a parent row: a foreign key constraint fails'];
  if((m = msg.match(/UNIQUE constraint failed: (\S+)/))) return ['Duplicate value. <code>'+esc(m[1])+'</code> must be unique and that value is already in the table.', "ERROR 1062 (23000): Duplicate entry for key"];
  if((m = msg.match(/NOT NULL constraint failed: (\S+)/))) return ['<code>'+esc(m[1])+'</code> is NOT NULL, so you have to give it a value.', "ERROR 1364 (HY000): Field doesn't have a default value"];
  if(/CHECK constraint failed/.test(msg)) return ['A CHECK rule refused this value.', 'ERROR 4025 (23000): CONSTRAINT failed'];
  if((m = msg.match(/table (\S+) already exists/))) return ['The table <code>'+esc(m[1])+'</code> already exists.', "ERROR 1050 (42S01): Table already exists"];
  if(/misuse of aggregate/.test(msg)) return ['You used an aggregate like AVG or COUNT where it is not allowed. Filters on aggregates go in HAVING, after GROUP BY.', 'ERROR 1111 (HY000): Invalid use of group function'];
  if(/no such function: (\w+)/.test(msg)) return ['Unknown function. Check the spelling.', 'ERROR 1305 (42000): FUNCTION does not exist'];
  return [esc(msg), ''];
}

/* ---------------- comparing ---------------- */
function nv(v){
  if(v===null || v===undefined) return 'NULL';
  if(typeof v==='number') return (Math.round(v*100)/100).toFixed(2);
  if(typeof v==='string' && /^-?\d+(\.\d+)?$/.test(v)) return (Math.round(parseFloat(v)*100)/100).toFixed(2);
  return String(v);
}
function rowsKey(set){ return set.values.map(r => r.map(nv).join('\u0001')); }
function compareSets(got, exp, o){
  if(!got) return { ok:false, why:'Your SQL ran, but it did not return a table of results. This task needs a SELECT.' };
  if(got.columns.length !== exp.columns.length) return { ok:false, why:'You returned <b>'+got.columns.length+'</b> column'+(got.columns.length==1?'':'s')+'; the answer has <b>'+exp.columns.length+'</b>: <code>'+exp.columns.map(esc).join(', ')+'</code>.' };
  if(got.values.length !== exp.values.length) return { ok:false, why:'You got <b>'+got.values.length+'</b> row'+(got.values.length==1?'':'s')+'; the answer has <b>'+exp.values.length+'</b>. Check your WHERE, JOIN or GROUP BY.' };
  const g = rowsKey(got), e = rowsKey(exp);
  const same = (a,b) => a.every((x,i) => x===b[i]);
  if(o.ordered){
    if(!same(g,e)){
      if(same([...g].sort(), [...e].sort())) return { ok:false, why:'The rows are right but in the wrong order. Check ORDER BY, and ASC or DESC.' };
      return { ok:false, why:'Right number of rows, but some values differ. Compare your table with the task.' };
    }
  } else if(!same([...g].sort(), [...e].sort())) return { ok:false, why:'Right number of rows, but some values differ. Compare your table with the task.' };
  if(o.names){
    const bad = got.columns.find((c,i) => c.toLowerCase() !== exp.columns[i].toLowerCase());
    if(bad!==undefined) return { ok:false, why:'The values are right. Now name the columns <code>'+exp.columns.map(esc).join(', ')+'</code> (use AS).' };
  }
  return { ok:true };
}
function sig(db, t){
  const one = sql => { const r = db.exec(sql); return r.length ? r[0].values : []; };
  const ex = one("SELECT sql FROM sqlite_master WHERE type='table' AND name='"+t+"'");
  if(!ex.length) return null;
  const nt = s => s.toUpperCase().replace(/\s+/g,'').replace(/^INTEGER/,'INT');
  return {
    autoinc: /AUTOINCREMENT/i.test(ex[0][0]),
    cols: one("PRAGMA table_info('"+t+"')").map(r => ({ name:r[1].toLowerCase(), type:nt(r[2]), notnull:!!r[3], pk:r[5]>0 })),
    fks: one("PRAGMA foreign_key_list('"+t+"')").map(r => (r[3]+'→'+r[2]+'.'+r[4]).toLowerCase()).sort(),
    uniq: one("PRAGMA index_list('"+t+"')").filter(r => r[2]===1 && r[3]==='u').map(r => one("PRAGMA index_info('"+r[1]+"')").map(x=>x[2].toLowerCase()).join(',')).sort()
  };
}
function compareSig(t, g, e){
  if(!g) return ['The table <code>'+t+'</code> was not created.'];
  const out = [];
  e.cols.forEach(c => {
    const h = g.cols.find(x => x.name===c.name);
    if(!h){ out.push('Column <code>'+c.name+'</code> is missing.'); return; }
    if(h.type!==c.type) out.push('Column <code>'+c.name+'</code> should be <code>'+c.type+'</code>, not <code>'+h.type+'</code>.');
    if(h.pk!==c.pk) out.push('Column <code>'+c.name+'</code> '+(c.pk?'should':'should not')+' be the PRIMARY KEY.');
    else if(!c.pk && h.notnull!==c.notnull) out.push('Column <code>'+c.name+'</code> '+(c.notnull?'should be NOT NULL.':'should allow NULL.'));
  });
  g.cols.forEach(c => { if(!e.cols.find(x => x.name===c.name)) out.push('Column <code>'+c.name+'</code> is not in the design.'); });
  if(e.autoinc && !g.autoinc) out.push('The id column should number itself (AUTO_INCREMENT).');
  const fk = f => { const [a,b] = f.split('→'); const [t2,c2] = b.split('.'); return '<code>FOREIGN KEY ('+a+') REFERENCES '+t2+'('+c2+')</code>'; };
  e.fks.forEach(f => { if(!g.fks.includes(f)) out.push('Missing '+fk(f)+'.'); });
  g.fks.forEach(f => { if(!e.fks.includes(f)) out.push('Unexpected '+fk(f)+'. Check the table and column it points to.'); });
  e.uniq.forEach(u => { if(!g.uniq.includes(u)) out.push('<code>'+u.replace(/,/g,', ')+'</code> should be UNIQUE.'); });
  g.uniq.forEach(u => { if(!e.uniq.includes(u)) out.push('<code>'+u.replace(/,/g,', ')+'</code> should not be UNIQUE.'); });
  return out;
}

/* ---------------- rendering ---------------- */
const KW = /\b(SELECT|FROM|WHERE|AND|OR|NOT|NULL|IS|IN|AS|ON|JOIN|LEFT|RIGHT|INNER|OUTER|GROUP|BY|ORDER|HAVING|LIMIT|OFFSET|ASC|DESC|DISTINCT|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|DROP|ALTER|PRIMARY|KEY|FOREIGN|REFERENCES|UNIQUE|AUTO_INCREMENT|DEFAULT|CHECK|INT|TINYINT|VARCHAR|CHAR|DECIMAL|DATE|TEXT|BETWEEN|LIKE|CASE|WHEN|THEN|ELSE|END|COUNT|AVG|SUM|MIN|MAX|ROUND|CONCAT|EXISTS|OVER|PARTITION|RANK|START|TRANSACTION|COMMIT|ROLLBACK|SHOW|TABLES|DESCRIBE|USE|DATABASE)\b/g;
function hl(text){
  return text.split(/('(?:[^']|'')*'|--[^\n]*)/g).map((p,i) => {
    if(i%2){ return p.startsWith('--') ? '<span class="cm">'+esc(p)+'</span>' : '<span class="st">'+esc(p)+'</span>'; }
    return esc(p).replace(KW, '<span class="kw">$1</span>').replace(/(^|[^\w.])(\d+(?:\.\d+)?)(?![\w])/g, '$1<span class="nu">$2</span>');
  }).join('');
}
function table(set, max){
  max = max || 60;
  if(!set) return '';
  if(!set.values.length) return '<div class="sqlx-empty">Empty set (0 rows)</div><div class="sqlx-tbl"><table><tr>'+set.columns.map(c=>'<th>'+esc(c)+'</th>').join('')+'</tr></table></div>';
  const rows = set.values.slice(0, max).map(r => '<tr>'+r.map(v => v===null ? '<td class="null">NULL</td>' : '<td'+(typeof v==='number'?' class="n"':'')+'>'+esc(typeof v==='number' ? +v.toFixed(4) : v)+'</td>').join('')+'</tr>').join('');
  return '<div class="sqlx-tbl"><table><tr>'+set.columns.map(c=>'<th>'+esc(c)+'</th>').join('')+'</tr>'+rows+'</table></div><div class="sqlx-count">'+set.values.length+' row'+(set.values.length==1?'':'s')+(set.values.length>max?' (showing '+max+')':'')+'</div>';
}
function errorBox(msg){
  const [plain, maria] = friendly(msg);
  return '<div class="sqlx-fb bad"><b>Error.</b> '+plain+(maria?'<div class="maria">MariaDB would say: <code>'+maria+'</code></div>':'')+'<div class="raw">SQLite said: '+esc(msg)+'</div></div>';
}

/* ---------------- progress ---------------- */
const page = 'sqlx:' + (location.pathname.split('/').pop() || 'page');
const solvedKey = id => page+':'+id;
function updateProgress(){
  document.querySelectorAll('[data-sqlx-progress]').forEach(el => {
    const track = el.dataset.sqlxProgress;
    const ids = Object.keys(window.SQLX_EX).filter(id => !window.SQLX_EX[id].demoOnly && (window.SQLX_EX[id].track||'main')===track && document.querySelector('[data-ex="'+id+'"]'));
    const n = ids.filter(id => store.get(solvedKey(id), false)).length;
    el.querySelector('.bar i').style.width = (100*n/Math.max(1,ids.length))+'%';
    el.querySelector('.lbl').textContent = n+' of '+ids.length+' solved';
  });
}

/* ---------------- one exercise ---------------- */
function parseTpl(tpl){
  const parts=[]; let last=0; const re=/\[\[(.*?)\]\]/g; let m;
  while((m = re.exec(tpl))){ parts.push(tpl.slice(last, m.index)); parts.push({ ans: m[1].split('|') }); last = re.lastIndex; }
  parts.push(tpl.slice(last)); return parts;
}
const normB = s => s.trim().replace(/\s+/g,' ').toLowerCase();

function build(el, ex, id){
  const free = !!ex.free;
  const parts = free ? null : parseTpl(ex.code);
  const solution = free ? ex.solution : parts.map(p => typeof p==='string' ? p : p.ans[0]).join('');
  el.classList.add('sqlx');
  let codeHTML;
  if(free) codeHTML = '<textarea class="sqlx-free" spellcheck="false" rows="'+Math.max(6, (ex.starter||'').split('\n').length+3)+'">'+esc(ex.starter||'')+'</textarea>';
  else codeHTML = '<pre class="sqlx-code">'+parts.map((p,i) => typeof p==='string' ? hl(p) : '<input class="blank" data-i="'+i+'" spellcheck="false" autocomplete="off" autocapitalize="off" aria-label="blank" style="width:'+(Math.max(3, ...p.ans.map(a=>a.length))+1.5)+'ch">').join('')+'</pre>';
  el.innerHTML =
    '<div class="sqlx-head"><span class="sqlx-badge">'+(free?'✍️ Write it yourself':'🧩 Fill in the blanks')+'</span><span class="sqlx-state"></span></div>'+
    codeHTML+
    '<div class="sqlx-btns"><button class="btn primary run" title="Ctrl+Enter">▶ Run &amp; check</button>'+
    '<button class="btn hint">💡 Hint</button><button class="btn show">👁 Show answer</button><button class="btn ghost reset">↺ Reset</button>'+
    (ex.demos||[]).map((d,i) => '<button class="btn demo" data-d="'+i+'">🧪 '+esc(d.label)+'</button>').join('')+
    '<span class="sqlx-key">Ctrl+Enter runs</span></div>'+
    '<div class="sqlx-hints"></div><div class="sqlx-out" aria-live="polite"></div>';
  const $ = s => el.querySelector(s);
  const inputs = [...el.querySelectorAll('input.blank')];
  const ta = $('textarea');
  const out = $('.sqlx-out'), hintsEl = $('.sqlx-hints'), state = $('.sqlx-state');
  let hintN = 0, busy = false;
  const draftKey = page+':draft:'+id;
  const draft = store.get(draftKey, null);
  if(draft){ if(free && typeof draft==='string') ta.value = draft; else if(Array.isArray(draft)) inputs.forEach((x,k) => x.value = draft[k]||''); }
  const saveDraft = () => store.set(draftKey, free ? ta.value : inputs.map(x=>x.value));
  el.addEventListener('input', () => { saveDraft(); inputs.forEach(x => x.classList.remove('ok','off')); });
  const paint = () => { const s = store.get(solvedKey(id), false); state.innerHTML = s ? '<span class="pill ok">✓ Solved</span>' : ''; el.classList.toggle('solved', !!s); };
  paint();

  const assemble = () => free ? ta.value : parts.map((p,i) => typeof p==='string' ? p : el.querySelector('input[data-i="'+i+'"]').value).join('');
  function markBlanks(allOk){
    inputs.forEach(x => {
      const p = parts[+x.dataset.i];
      const good = p.ans.some(a => normB(a)===normB(x.value));
      x.classList.toggle('ok', allOk || good); x.classList.toggle('off', !allOk && !good);
    });
  }

  async function check(){
    if(busy) return; busy = true;
    try{
      if(!free && inputs.some(x => !x.value.trim())){
        inputs.forEach(x => x.classList.toggle('off', !x.value.trim()));
        out.innerHTML = '<div class="sqlx-fb info">Fill in every blank first. The empty ones are marked in red.</div>'; return;
      }
      const sql = assemble();
      if(!sql.trim()){ out.innerHTML = '<div class="sqlx-fb info">Write your SQL first.</div>'; return; }
      out.innerHTML = '<div class="sqlx-fb info">Running…</div>';
      const db = await freshDB(ex.setup||'full', ex.setupSql);
      const r = run(db, sql);
      if(r.error){ db.close(); out.innerHTML = errorBox(r.error); if(!free) markBlanks(false); return; }
      const ref = await freshDB(ex.setup||'full', ex.setupSql); const rr = run(ref, solution);
      if(rr.error) console.error('reference answer failed', id, rr.error);
      let verdict, shown = '';
      if(ex.check==='schema'){
        const problems = []; ex.tables.forEach(t => problems.push(...compareSig(t, sig(db,t), sig(ref,t))));
        verdict = problems.length ? { ok:false, why:'<ul>'+problems.map(p=>'<li>'+p+'</li>').join('')+'</ul>' } : { ok:true };
        const t = ex.tables[ex.tables.length-1];
        const d = run(db, 'DESCRIBE '+t);
        if(sig(db,t)) shown = '<div class="sqlx-cap">DESCRIBE '+t+';</div>'+table(d.last);
      } else if(ex.verify){
        const gv = run(db, ex.verify).last, ev = run(ref, ex.verify).last;
        verdict = (ex.changes!==undefined && r.changes!==ex.changes)
          ? { ok:false, why:'Your SQL changed <b>'+r.changes+'</b> row'+(r.changes==1?'':'s')+'. It should change <b>'+ex.changes+'</b>. Check your WHERE.' }
          : compareSets(gv, ev, { ordered:true });
        shown = (r.wrote ? '<div class="sqlx-cap">'+r.changes+' row'+(r.changes==1?'':'s')+' affected</div>' : '') + (r.last ? table(r.last) : '') +
                '<div class="sqlx-cap">Check query: <code>'+esc(ex.verify)+'</code></div>'+table(gv, ex.showRows||12);
      } else {
        verdict = compareSets(r.last, rr.last, { ordered: ex.ordered!==undefined ? ex.ordered : /\border\s+by\b(?![^()]*\))/i.test(solution), names: !!ex.names });
        shown = table(r.last);
      }
      if(verdict.ok && ex.mustContain){
        const miss = ex.mustContain.find(m => !new RegExp(m[0], 'i').test(sql));
        if(miss) verdict = { ok:false, why: miss[1] };
      }
      db.close(); ref.close();
      if(!free) markBlanks(verdict.ok);
      if(verdict.ok){
        store.set(solvedKey(id), true); paint(); updateProgress();
        out.innerHTML = '<div class="sqlx-fb ok"><b>✓ Correct.</b> '+(ex.success||'')+'</div>'+shown;
      } else {
        out.innerHTML = '<div class="sqlx-fb bad"><b>Not yet.</b> '+verdict.why+(free?'':' Blanks that differ from the model answer are marked in red.')+'</div>'+shown;
      }
    } finally { busy = false; }
  }
  $('.run').onclick = check;
  el.addEventListener('keydown', e => {
    if((e.key==='Enter' && (e.ctrlKey||e.metaKey)) || (e.key==='Enter' && e.target.classList.contains('blank'))){ e.preventDefault(); check(); }
  });
  $('.hint').onclick = () => {
    const h = ex.hints||[];
    if(hintN < h.length){ hintsEl.insertAdjacentHTML('beforeend', '<div class="sqlx-hint">💡 '+h[hintN]+'</div>'); hintN++; }
    if(hintN >= h.length){ $('.hint').disabled = true; $('.hint').textContent = '💡 No more hints'; }
  };
  $('.show').onclick = async () => {
    if(free) ta.value = solution; else inputs.forEach(x => x.value = parts[+x.dataset.i].ans[0]);
    saveDraft();
    const ref = await freshDB(ex.setup||'full', ex.setupSql); const rr = run(ref, solution);
    const vv = ex.verify ? run(ref, ex.verify).last : null; ref.close();
    out.innerHTML = '<div class="sqlx-fb info">Here is the model answer. Read it, then press <b>Run &amp; check</b>.'+(ex.why?'<div style="margin-top:.4rem">'+ex.why+'</div>':'')+'</div>'+
      (ex.check!=='schema' && (vv||rr.last) ? '<div class="sqlx-cap">What the answer gives</div>'+table(vv||rr.last, ex.showRows||12) : '');
  };
  $('.reset').onclick = () => { if(free) ta.value = ex.starter||''; else inputs.forEach(x => { x.value=''; x.classList.remove('ok','off'); }); saveDraft(); out.innerHTML=''; };
  el.querySelectorAll('.demo').forEach(b => b.onclick = async () => {
    const d = ex.demos[+b.dataset.d];
    const db = await freshDB(d.setup||ex.setup||'full', ex.setupSql);
    const r = run(db, d.sql);
    let h = '<div class="sqlx-cap">🧪 Experiment: <code>'+esc(d.sql)+'</code></div>';
    if(r.error) h += errorBox(r.error);
    else {
      if(r.wrote) h += '<div class="sqlx-fb warn"><b>'+r.changes+' row'+(r.changes==1?'':'s')+' affected.</b>'+(d.note?' '+d.note:'')+'</div>';
      else if(d.note) h += '<div class="sqlx-fb warn">'+d.note+'</div>';
      if(r.last) h += table(r.last);
      if(d.after){ h += '<div class="sqlx-cap">Then: <code>'+esc(d.after)+'</code></div>' + table(run(db, d.after).last, 12); }
    }
    h += '<div class="sqlx-small">The experiment ran on a throwaway copy. Your exercise data is untouched.</div>';
    db.close(); out.innerHTML = h;
  });
}

/* ---------------- free sandbox that keeps its data ---------------- */
async function playground(el){
  el.classList.add('sqlx');
  el.innerHTML = '<div class="sqlx-head"><span class="sqlx-badge">🧪 Sandbox: your changes stay until you press Reset</span></div>'+
    '<div class="sqlx-chips"></div>'+
    '<textarea class="sqlx-free" spellcheck="false" rows="7">SELECT * FROM students;</textarea>'+
    '<div class="sqlx-btns"><button class="btn primary run">▶ Run</button><button class="btn ghost reset">↺ Reset database</button><span class="sqlx-key">Ctrl+Enter runs · several statements are fine, separate them with ;</span></div>'+
    '<div class="sqlx-out" aria-live="polite"></div>';
  const ta = el.querySelector('textarea'), out = el.querySelector('.sqlx-out'), chips = el.querySelector('.sqlx-chips');
  let db = await freshDB('full');
  const key = page+':sandbox'; const saved = store.get(key, null); if(saved) ta.value = saved;
  ta.addEventListener('input', () => store.set(key, ta.value));
  const paintChips = () => {
    const r = db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name");
    chips.innerHTML = 'Tables: ' + (r.length ? r[0].values.map(v => '<button class="btn ghost chip" data-t="'+esc(v[0])+'">'+esc(v[0])+'</button>').join('') : '<i>none</i>');
    chips.querySelectorAll('.chip').forEach(b => b.onclick = () => { ta.value = 'SELECT * FROM '+b.dataset.t+';'; go(); });
  };
  const go = () => {
    const r = run(db, ta.value);
    let h = '';
    r.sets.forEach((s,i) => { if(i < r.sets.length-3) return; h += table(s); });
    if(r.wrote) h += '<div class="sqlx-cap">'+r.changes+' row'+(r.changes==1?'':'s')+' affected</div>';
    if(r.error) h += errorBox(r.error);
    if(!h) h = '<div class="sqlx-fb info">Query OK.</div>';
    out.innerHTML = h; paintChips();
  };
  el.querySelector('.run').onclick = go;
  el.querySelector('.reset').onclick = async () => { db.close(); db = await freshDB('full'); out.innerHTML = '<div class="sqlx-fb info">Database reset to the original school data.</div>'; paintChips(); };
  el.addEventListener('keydown', e => { if(e.key==='Enter' && (e.ctrlKey||e.metaKey)){ e.preventDefault(); go(); } });
  paintChips();
}

/* ---------------- boot ---------------- */
window.SQLX = { split, translate, run, freshDB, getSQL, compareSets, sig, compareSig, hl, table, updateProgress };
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-ex]').forEach(el => { const id = el.dataset.ex; const ex = window.SQLX_EX[id]; if(ex) build(el, ex, id); else el.textContent = 'Missing exercise '+id; });
  document.querySelectorAll('pre.sqlx-show').forEach(p => { p.innerHTML = hl(p.textContent.replace(/^\n+|\s+$/g,'')); });
  document.querySelectorAll('[data-playground]').forEach(el => playground(el));
  updateProgress();
  getSQL().catch(e => document.querySelectorAll('.sqlx-out').forEach(o => o.innerHTML = '<div class="sqlx-fb bad">The SQL engine could not start in this browser: '+esc(e.message)+'. Use your MariaDB terminal instead.</div>'));
});
})();
